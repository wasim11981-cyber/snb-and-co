export type TransactionType = 'GIVE_STOCK' | 'TAKE_STOCK'; // GIVE = Outward (Sale), TAKE = Inward (Purchase)

export type PaymentType = 'PAYMENT_RECEIVED' | 'PAYMENT_PAID';

export type PaymentMethod = 'CASH' | 'BANK_TRANSFER' | 'UPI' | 'CHEQUE';

export interface Company {
  id: string;
  name: string;
  contactPerson?: string;
  phone: string;
  email?: string;
  address?: string;
  gstNumber?: string;
  createdAt: string;
  initialBalance?: number; // positive: client owes us, negative: we owe client
}

export interface LineItem {
  id: string;
  sNo: number;
  itemName: string;
  boxes: number;
  weightPerBox: number; // weight of box
  looseWeight: number;
  totalWeight: number; // (boxes * weightPerBox) + looseWeight
  lessPercentage: number; // default 5.0
  lessWeight: number; // totalWeight * (lessPercentage / 100)
  weightAfterLess: number; // totalWeight - lessWeight
  rate: number; // rate per unit weight (kg)
  subTotal: number; // weightAfterLess * rate
}

export interface Transaction {
  id: string;
  invoiceNumber: string; // e.g. SNB-OUT-001 or SNB-INW-001
  type: TransactionType;
  companyId: string;
  companyName: string;
  date: string; // ISO date YYYY-MM-DD
  items: LineItem[];
  totalBoxes: number;
  totalGrossWeight: number;
  totalLessWeight: number;
  totalWeightAfterLess: number;
  finalInvoiceTotal: number; // aggregated sum of all subTotals
  notes?: string;
  vehicleNumber?: string;
  createdAt: string;
}

export interface Payment {
  id: string;
  receiptNumber: string;
  companyId: string;
  companyName: string;
  type: PaymentType; // RECEIVED (reduces receivable) or PAID (reduces payable)
  amount: number;
  paymentMethod: PaymentMethod;
  referenceNumber?: string; // cheque no, UTR, UPI ref
  notes?: string;
  date: string;
  createdAt: string;
}

export interface LedgerEntry {
  id: string;
  date: string;
  particulars: string;
  type: 'GIVE_STOCK' | 'TAKE_STOCK' | 'PAYMENT_RECEIVED' | 'PAYMENT_PAID' | 'OPENING_BALANCE';
  referenceId: string;
  referenceDocNo: string;
  debit: number; // Dr: Client owes us (Give Stock, Payment Paid to Client)
  credit: number; // Cr: We owe client (Take Stock, Payment Received from Client)
  runningBalance: number; // positive = Dr (client owes SNB), negative = Cr (SNB owes client)
  notes?: string;
}

export interface InventoryItem {
  itemName: string;
  totalBoxesInStock: number;
  totalNetWeightKg: number;
  averageRate: number;
  lastUpdated: string;
  stockHistoryCount: number;
}
