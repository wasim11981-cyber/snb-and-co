import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Printer, 
  Eye, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Calendar, 
  Building2, 
  Trash2 
} from 'lucide-react';
import { Transaction } from '../types';
import { formatCurrency, formatDate, formatWeight } from '../utils/formatters';

interface InvoicesListViewProps {
  transactions: Transaction[];
  onViewInvoice: (transaction: Transaction) => void;
  onOpenLedger: (companyId: string) => void;
  onDeleteTransaction: (id: string) => void;
  onOpenNewTransaction: (type: 'GIVE_STOCK' | 'TAKE_STOCK') => void;
}

export const InvoicesListView: React.FC<InvoicesListViewProps> = ({
  transactions,
  onViewInvoice,
  onOpenLedger,
  onDeleteTransaction,
  onOpenNewTransaction,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'GIVE_STOCK' | 'TAKE_STOCK'>('ALL');

  const filtered = transactions.filter(t => {
    if (typeFilter !== 'ALL' && t.type !== typeFilter) return false;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return (
        t.invoiceNumber.toLowerCase().includes(term) ||
        t.companyName.toLowerCase().includes(term) ||
        t.items.some(i => i.itemName.toLowerCase().includes(term)) ||
        (t.vehicleNumber && t.vehicleNumber.toLowerCase().includes(term))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-6 h-6 text-sky-600" />
            <span>Generated Invoices & Stock Bills</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Official records with detailed box weight & less (5%) calculations
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Filter Type Pills */}
          <div className="flex bg-slate-100 p-1 rounded-lg text-xs font-bold">
            <button
              onClick={() => setTypeFilter('ALL')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                typeFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Invoices ({transactions.length})
            </button>
            <button
              onClick={() => setTypeFilter('GIVE_STOCK')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                typeFilter === 'GIVE_STOCK' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Give Stock (Outward)
            </button>
            <button
              onClick={() => setTypeFilter('TAKE_STOCK')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                typeFilter === 'TAKE_STOCK' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Take Stock (Inward)
            </button>
          </div>

          {/* Search Input */}
          <div className="relative min-w-[220px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search invoice #, company..."
              className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-sky-500"
            />
          </div>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 w-28">Date</th>
                <th className="py-3 px-3 w-32 font-mono">Invoice #</th>
                <th className="py-3 px-3 text-center">Type</th>
                <th className="py-3 px-4">Party / Company</th>
                <th className="py-3 px-3 text-center">Boxes</th>
                <th className="py-3 px-3 text-right">Net Wt (After Less)</th>
                <th className="py-3 px-4 text-right font-bold text-slate-900">Total Amount (₹)</th>
                <th className="py-3 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 italic">
                    No invoices found matching criteria.
                  </td>
                </tr>
              ) : (
                filtered.map(t => {
                  const isGive = t.type === 'GIVE_STOCK';
                  return (
                    <tr key={t.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-700 whitespace-nowrap">
                        {formatDate(t.date)}
                      </td>

                      <td className="py-3 px-3 font-mono font-bold text-sky-700">
                        {t.invoiceNumber}
                      </td>

                      <td className="py-3 px-3 text-center">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          isGive
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-sky-100 text-sky-800 border border-sky-200'
                        }`}>
                          {isGive ? (
                            <>
                              <ArrowUpRight className="w-3 h-3" /> Give (Out)
                            </>
                          ) : (
                            <>
                              <ArrowDownLeft className="w-3 h-3" /> Take (In)
                            </>
                          )}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <button
                          type="button"
                          onClick={() => onOpenLedger(t.companyId)}
                          className="font-bold text-slate-900 hover:text-sky-700 hover:underline text-left block"
                        >
                          {t.companyName}
                        </button>
                        <span className="text-[11px] text-slate-500">
                          {t.items.map(i => i.itemName).join(', ')}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-center font-mono font-semibold text-slate-700">
                        {t.totalBoxes} bxs
                      </td>

                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-800">
                        {formatWeight(t.totalWeightAfterLess)}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-black text-slate-950 text-sm">
                        {formatCurrency(t.finalInvoiceTotal)}
                      </td>

                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => onViewInvoice(t)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-sky-50 hover:bg-sky-100 text-sky-800 rounded font-bold transition-colors"
                            title="View Full Invoice"
                          >
                            <Eye className="w-3 h-3" />
                            <span>View</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => onViewInvoice(t)}
                            className="p-1 text-slate-400 hover:text-slate-800 rounded"
                            title="Print Invoice"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm(`Delete invoice ${t.invoiceNumber}? This will revert client ledger and inventory.`)) {
                                onDeleteTransaction(t.id);
                              }
                            }}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded"
                            title="Delete transaction"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
