import React, { useState } from 'react';
import { Building2, X, CheckCircle2, Phone, MapPin, User, FileText } from 'lucide-react';
import { Company } from '../types';

interface AddCompanyModalProps {
  onSave: (company: Company) => void;
  onClose: () => void;
}

export const AddCompanyModal: React.FC<AddCompanyModalProps> = ({
  onSave,
  onClose,
}) => {
  const [name, setName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [gstNumber, setGstNumber] = useState('');
  const [initialBalance, setInitialBalance] = useState('');
  const [balanceType, setBalanceType] = useState<'Dr' | 'Cr'>('Dr');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Company Name is required.');
      return;
    }

    const initBalNum = parseFloat(initialBalance) || 0;
    const signedBalance = balanceType === 'Dr' ? Math.abs(initBalNum) : -Math.abs(initBalNum);

    const newCompany: Company = {
      id: `comp-${Date.now()}`,
      name: name.trim(),
      contactPerson: contactPerson.trim(),
      phone: phone.trim(),
      email: email.trim(),
      address: address.trim(),
      gstNumber: gstNumber.trim().toUpperCase(),
      initialBalance: signedBalance,
      createdAt: new Date().toISOString().split('T')[0],
    };

    onSave(newCompany);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold">Add New Company / Client</h3>
              <p className="text-xs text-slate-400">Register company for stock ledger</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMsg && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-3 rounded-lg text-xs">
              {errorMsg}
            </div>
          )}

          {/* Company Name */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
              Company / Firm Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g. Malabar Spices & Commodities"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-semibold focus:ring-2 focus:ring-sky-500"
              required
            />
          </div>

          {/* Contact Person & Phone */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1 mb-1">
                <User className="w-3 h-3 text-sky-600" />
                <span>Contact Person</span>
              </label>
              <input
                type="text"
                value={contactPerson}
                onChange={e => setContactPerson(e.target.value)}
                placeholder="e.g. Rajesh Kumar"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1 mb-1">
                <Phone className="w-3 h-3 text-sky-600" />
                <span>Phone / Mobile</span>
              </label>
              <input
                type="text"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+91 98..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-sky-500"
              />
            </div>
          </div>

          {/* Address */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1 mb-1">
              <MapPin className="w-3 h-3 text-sky-600" />
              <span>Address / Market Yard</span>
            </label>
            <textarea
              value={address}
              onChange={e => setAddress(e.target.value)}
              placeholder="e.g. Shop 12, APMC Market Complex"
              rows={2}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* GST Number */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1 mb-1">
              <FileText className="w-3 h-3 text-sky-600" />
              <span>GSTIN / Tax ID (Optional)</span>
            </label>
            <input
              type="text"
              value={gstNumber}
              onChange={e => setGstNumber(e.target.value)}
              placeholder="e.g. 29ABCDE1234F1Z5"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-medium focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Opening Balance */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
              Opening Balance (If any)
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                step="any"
                min="0"
                value={initialBalance}
                onChange={e => setInitialBalance(e.target.value)}
                placeholder="0.00"
                className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-sky-500"
              />
              <select
                value={balanceType}
                onChange={e => setBalanceType(e.target.value as 'Dr' | 'Cr')}
                className="w-28 px-2 py-2 border border-slate-300 rounded-lg text-xs font-bold bg-slate-50"
              >
                <option value="Dr">Dr (Owes Us)</option>
                <option value="Cr">Cr (We Owe)</option>
              </select>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Dr = Client owes SNB AND CO &bull; Cr = SNB AND CO owes Client
            </p>
          </div>

          <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded-lg shadow-sm transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Save Company</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
