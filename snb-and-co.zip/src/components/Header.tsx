import React from 'react';
import { 
  Building2, 
  TrendingUp, 
  TrendingDown, 
  Boxes, 
  PlusCircle, 
  ArrowDownLeft, 
  ArrowUpRight 
} from 'lucide-react';
import { formatCurrency, formatWeight } from '../utils/formatters';

interface HeaderProps {
  totalReceivable: number;
  totalPayable: number;
  totalInventoryWeight: number;
  totalInventoryBoxes: number;
  onOpenNewTransaction: (type: 'GIVE_STOCK' | 'TAKE_STOCK') => void;
  onOpenPaymentModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  totalReceivable,
  totalPayable,
  totalInventoryWeight,
  totalInventoryBoxes,
  onOpenNewTransaction,
  onOpenPaymentModal,
}) => {
  return (
    <header className="bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white shadow-xl border-b border-sky-800/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          {/* Brand Identity */}
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20 text-slate-950 font-black text-2xl tracking-wider">
              SNB
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
                  SNB AND CO
                </h1>
                <span className="bg-sky-500/20 text-sky-300 text-xs font-semibold px-2.5 py-0.5 rounded-full border border-sky-500/30">
                  Enterprise Ledger
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Wholesale Commodity Stock Trading, Client Ledgers & Real-time Inventory
              </p>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onOpenNewTransaction('GIVE_STOCK')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold shadow-md transition-all active:scale-95"
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>Give Stock (Outward)</span>
            </button>

            <button
              onClick={() => onOpenNewTransaction('TAKE_STOCK')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold shadow-md transition-all active:scale-95"
            >
              <ArrowDownLeft className="w-4 h-4" />
              <span>Take Stock (Inward)</span>
            </button>

            <button
              onClick={onOpenPaymentModal}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-sm font-bold shadow-md transition-all active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Record Payment</span>
            </button>
          </div>
        </div>

        {/* Real-time Metric Cards Banner */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 mt-6 pt-5 border-t border-slate-700/60">
          {/* Total Receivable */}
          <div className="bg-slate-800/60 backdrop-blur-sm rounded-xl p-3.5 border border-slate-700/50 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                <TrendingUp className="w-4 h-4" />
                <span>Total Receivable (To Receive)</span>
              </div>
              <div className="text-xl font-bold text-white mt-1">
                {formatCurrency(totalReceivable)}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">From clients given stock</p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400 border border-emerald-500/20">
              Dr
            </div>
          </div>

          {/* Total Payable */}
          <div className="bg-slate-800/60 backdrop-blur-sm rounded-xl p-3.5 border border-slate-700/50 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-rose-400 font-medium">
                <TrendingDown className="w-4 h-4" />
                <span>Total Payable (To Pay)</span>
              </div>
              <div className="text-xl font-bold text-white mt-1">
                {formatCurrency(totalPayable)}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">To suppliers taken stock</p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400 border border-rose-500/20">
              Cr
            </div>
          </div>

          {/* Real-time Inventory */}
          <div className="bg-slate-800/60 backdrop-blur-sm rounded-xl p-3.5 border border-slate-700/50 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-amber-400 font-medium">
                <Boxes className="w-4 h-4" />
                <span>Real-Time Inventory in Stock</span>
              </div>
              <div className="text-xl font-bold text-white mt-1">
                {formatWeight(totalInventoryWeight)}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Across {totalInventoryBoxes} total boxes
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 border border-amber-500/20">
              <Boxes className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
