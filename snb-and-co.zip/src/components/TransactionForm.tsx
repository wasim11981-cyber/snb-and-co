import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Calculator, 
  CheckCircle2, 
  X, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Building2,
  Calendar,
  Truck,
  FileText
} from 'lucide-react';
import { Company, LineItem, Transaction, TransactionType } from '../types';
import { calculateLineItem, calculateAggregatedTotals } from '../utils/calculation';
import { formatCurrency, formatWeight } from '../utils/formatters';
import { generateNextNumber } from '../utils/storage';

interface TransactionFormProps {
  companies: Company[];
  initialType?: TransactionType;
  selectedCompanyId?: string;
  onSave: (transaction: Transaction) => void;
  onCancel: () => void;
  onAddNewCompany: () => void;
}

interface ItemRowInput {
  id: string;
  itemName: string;
  boxes: string;
  weightPerBox: string;
  looseWeight: string;
  lessPercentage: string;
  rate: string;
}

export const TransactionForm: React.FC<TransactionFormProps> = ({
  companies,
  initialType = 'GIVE_STOCK',
  selectedCompanyId,
  onSave,
  onCancel,
  onAddNewCompany,
}) => {
  const [type, setType] = useState<TransactionType>(initialType);
  const [companyId, setCompanyId] = useState<string>(selectedCompanyId || (companies[0]?.id || ''));
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [invoiceNumber, setInvoiceNumber] = useState<string>(
    generateNextNumber(type === 'GIVE_STOCK' ? 'OUT' : 'INW')
  );
  const [vehicleNumber, setVehicleNumber] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  // Rows of items
  const [rows, setRows] = useState<ItemRowInput[]>([
    {
      id: 'row-1',
      itemName: 'Cardamom Special (8mm)',
      boxes: '10',
      weightPerBox: '20',
      looseWeight: '5',
      lessPercentage: '5',
      rate: '1800',
    },
    {
      id: 'row-2',
      itemName: 'Black Pepper Bold (Grade A)',
      boxes: '15',
      weightPerBox: '25',
      looseWeight: '2',
      lessPercentage: '5',
      rate: '620',
    }
  ]);

  // Handle Type Change
  const handleTypeChange = (newType: TransactionType) => {
    setType(newType);
    setInvoiceNumber(generateNextNumber(newType === 'GIVE_STOCK' ? 'OUT' : 'INW'));
  };

  // Update a row field
  const handleRowChange = (id: string, field: keyof ItemRowInput, value: string) => {
    setRows(prev =>
      prev.map(row => (row.id === id ? { ...row, [field]: value } : row))
    );
  };

  // Add new empty item row
  const handleAddRow = () => {
    setRows(prev => [
      ...prev,
      {
        id: `row-${Date.now()}`,
        itemName: '',
        boxes: '',
        weightPerBox: '',
        looseWeight: '0',
        lessPercentage: '5',
        rate: '',
      }
    ]);
  };

  // Delete item row
  const handleDeleteRow = (id: string) => {
    if (rows.length === 1) {
      setErrorMsg('At least one item row is required.');
      return;
    }
    setErrorMsg('');
    setRows(prev => prev.filter(r => r.id !== id));
  };

  // Compute calculated line items using the formula:
  // BOX * WEIGHT OF BOX + LOOSE WEIGHT = TOTAL WEIGHT
  // THEN LESS 5% = WEIGHT AFTER LESS
  // WEIGHT AFTER LESS * RATE = SUB TOTAL
  const calculatedItems: LineItem[] = rows.map((row, idx) => {
    const boxes = parseFloat(row.boxes) || 0;
    const weightPerBox = parseFloat(row.weightPerBox) || 0;
    const looseWeight = parseFloat(row.looseWeight) || 0;
    const lessPct = parseFloat(row.lessPercentage) || 5;
    const rate = parseFloat(row.rate) || 0;

    return calculateLineItem(
      idx + 1,
      row.itemName || `Item #${idx + 1}`,
      boxes,
      weightPerBox,
      looseWeight,
      rate,
      lessPct
    );
  });

  const totals = calculateAggregatedTotals(calculatedItems);

  // Submit transaction
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyId) {
      setErrorMsg('Please select a company/client.');
      return;
    }
    const selectedComp = companies.find(c => c.id === companyId);
    if (!selectedComp) {
      setErrorMsg('Selected company not found.');
      return;
    }
    const validItems = calculatedItems.filter(i => i.itemName.trim() !== '' && i.subTotal > 0);
    if (validItems.length === 0) {
      setErrorMsg('Please add at least one valid item with boxes, weight, and rate.');
      return;
    }

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      invoiceNumber: invoiceNumber.trim() || generateNextNumber(type === 'GIVE_STOCK' ? 'OUT' : 'INW'),
      type,
      companyId: selectedComp.id,
      companyName: selectedComp.name,
      date,
      items: validItems,
      totalBoxes: totals.totalBoxes,
      totalGrossWeight: totals.totalGrossWeight,
      totalLessWeight: totals.totalLessWeight,
      totalWeightAfterLess: totals.totalWeightAfterLess,
      finalInvoiceTotal: totals.finalInvoiceTotal,
      notes: notes.trim(),
      vehicleNumber: vehicleNumber.trim(),
      createdAt: new Date().toISOString(),
    };

    onSave(newTx);
  };

  const selectedCompany = companies.find(c => c.id === companyId);

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
      {/* Form Header */}
      <div className="bg-slate-900 text-white px-6 py-4 flex flex-wrap items-center justify-between gap-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl ${type === 'GIVE_STOCK' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-sky-500/20 text-sky-400 border border-sky-500/30'}`}>
            {type === 'GIVE_STOCK' ? <ArrowUpRight className="w-6 h-6" /> : <ArrowDownLeft className="w-6 h-6" />}
          </div>
          <div>
            <h2 className="text-xl font-bold">
              {type === 'GIVE_STOCK' ? 'New Stock Delivery (Give Stock)' : 'New Stock Intake (Take Stock)'}
            </h2>
            <p className="text-xs text-slate-300">
              {type === 'GIVE_STOCK'
                ? 'Outward stock to client · Debits client ledger & updates inventory'
                : 'Inward stock from supplier/client · Credits client ledger & updates inventory'}
            </p>
          </div>
        </div>

        {/* Transaction Type Segmented Switch */}
        <div className="flex bg-slate-800 p-1 rounded-xl border border-slate-700">
          <button
            type="button"
            onClick={() => handleTypeChange('GIVE_STOCK')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              type === 'GIVE_STOCK'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Give Stock (Outward)
          </button>
          <button
            type="button"
            onClick={() => handleTypeChange('TAKE_STOCK')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              type === 'TAKE_STOCK'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Take Stock (Inward)
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        {/* Error message alert */}
        {errorMsg && (
          <div className="bg-rose-50 border border-rose-200 text-rose-800 px-4 py-3 rounded-xl text-sm flex items-center justify-between">
            <span>{errorMsg}</span>
            <button type="button" onClick={() => setErrorMsg('')} className="text-rose-500 hover:text-rose-700">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Basic Transaction Info */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-50/80 p-4 rounded-xl border border-slate-200">
          {/* Company Selection */}
          <div className="md:col-span-2">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-sky-600" />
                <span>Select Company / Client *</span>
              </label>
              <button
                type="button"
                onClick={onAddNewCompany}
                className="text-xs text-sky-600 hover:text-sky-800 font-semibold"
              >
                + Add New
              </button>
            </div>
            <select
              value={companyId}
              onChange={e => setCompanyId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 font-medium"
              required
            >
              <option value="">-- Choose Company --</option>
              {companies.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.phone ? `(${c.phone})` : ''}
                </option>
              ))}
            </select>
            {selectedCompany && (
              <p className="text-[11px] text-slate-500 mt-1 truncate">
                Address: {selectedCompany.address || 'No address specified'}
              </p>
            )}
          </div>

          {/* Date */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-1.5">
              <Calendar className="w-3.5 h-3.5 text-sky-600" />
              <span>Date *</span>
            </label>
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              required
            />
          </div>

          {/* Invoice / Note Number */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-1.5">
              <FileText className="w-3.5 h-3.5 text-sky-600" />
              <span>Doc / Invoice # *</span>
            </label>
            <input
              type="text"
              value={invoiceNumber}
              onChange={e => setInvoiceNumber(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 font-mono font-medium"
              required
            />
          </div>
        </div>

        {/* Calculation Logic Instruction Banner */}
        <div className="bg-sky-50 border border-sky-200/80 rounded-xl p-3.5 flex items-start gap-3 text-sky-950">
          <Calculator className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed">
            <span className="font-bold text-sky-900 uppercase tracking-wider">SNB AND CO Calculation Logic: </span>
            <span className="font-semibold text-slate-800">
              Total Wt = (Box × Wt of Box) + Loose Wt &nbsp;→&nbsp; Less 5% Tare &nbsp;→&nbsp; Weight After Less × Rate = Sub Total.
            </span>
            <span className="text-sky-700 block mt-0.5">
              All Sub Totals aggregate to produce the final transaction total automatically.
            </span>
          </div>
        </div>

        {/* Interactive Line Items Calculation Table */}
        <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/90 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-2 w-10 text-center">S.No</th>
                  <th className="py-3 px-3 min-w-[180px]">Item Name</th>
                  <th className="py-3 px-2 min-w-[70px]">Box</th>
                  <th className="py-3 px-2 min-w-[85px]">Wt of Box (kg)</th>
                  <th className="py-3 px-2 min-w-[80px]">Loose Wt (kg)</th>
                  <th className="py-3 px-2 min-w-[90px] bg-slate-200/50">Total Wt (kg)</th>
                  <th className="py-3 px-2 min-w-[80px] text-amber-700 bg-amber-50/50">Less 5%</th>
                  <th className="py-3 px-2 min-w-[95px] bg-emerald-50/50 text-emerald-800 font-extrabold">Net Wt (kg)</th>
                  <th className="py-3 px-2 min-w-[85px]">Rate (₹)</th>
                  <th className="py-3 px-3 min-w-[110px] text-right font-extrabold bg-sky-50/50">Sub Total (₹)</th>
                  <th className="py-3 px-2 w-10 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {rows.map((row, index) => {
                  const calc = calculatedItems[index];
                  return (
                    <tr key={row.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* S.No */}
                      <td className="py-2.5 px-2 text-center font-bold text-slate-500">
                        {index + 1}
                      </td>

                      {/* Item Name */}
                      <td className="py-2.5 px-3">
                        <input
                          type="text"
                          value={row.itemName}
                          onChange={e => handleRowChange(row.id, 'itemName', e.target.value)}
                          placeholder="e.g. Cardamom Green"
                          className="w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs focus:ring-1 focus:ring-sky-500 font-medium"
                          required
                        />
                      </td>

                      {/* Box */}
                      <td className="py-2.5 px-2">
                        <input
                          type="number"
                          step="any"
                          min="0"
                          value={row.boxes}
                          onChange={e => handleRowChange(row.id, 'boxes', e.target.value)}
                          placeholder="0"
                          className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs font-mono text-center focus:ring-1 focus:ring-sky-500"
                          required
                        />
                      </td>

                      {/* Weight of Box */}
                      <td className="py-2.5 px-2">
                        <input
                          type="number"
                          step="any"
                          min="0"
                          value={row.weightPerBox}
                          onChange={e => handleRowChange(row.id, 'weightPerBox', e.target.value)}
                          placeholder="0.0"
                          className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs font-mono text-center focus:ring-1 focus:ring-sky-500"
                          required
                        />
                      </td>

                      {/* Loose Weight */}
                      <td className="py-2.5 px-2">
                        <input
                          type="number"
                          step="any"
                          min="0"
                          value={row.looseWeight}
                          onChange={e => handleRowChange(row.id, 'looseWeight', e.target.value)}
                          placeholder="0.0"
                          className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs font-mono text-center focus:ring-1 focus:ring-sky-500"
                        />
                      </td>

                      {/* Total Weight (Auto calculated) */}
                      <td className="py-2.5 px-2 font-mono font-bold text-slate-800 bg-slate-100/60">
                        {calc ? calc.totalWeight.toFixed(3) : '0.000'}
                      </td>

                      {/* Less 5% (Auto calculated) */}
                      <td className="py-2.5 px-2 font-mono text-amber-700 bg-amber-50/40 font-medium">
                        - {calc ? calc.lessWeight.toFixed(3) : '0.000'}
                        <span className="block text-[10px] text-amber-600/80 font-normal">
                          (5%)
                        </span>
                      </td>

                      {/* Weight After Less (Auto calculated) */}
                      <td className="py-2.5 px-2 font-mono font-bold text-emerald-700 bg-emerald-50/60">
                        {calc ? calc.weightAfterLess.toFixed(3) : '0.000'}
                      </td>

                      {/* Rate */}
                      <td className="py-2.5 px-2">
                        <input
                          type="number"
                          step="any"
                          min="0"
                          value={row.rate}
                          onChange={e => handleRowChange(row.id, 'rate', e.target.value)}
                          placeholder="Rate ₹"
                          className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs font-mono text-right focus:ring-1 focus:ring-sky-500"
                          required
                        />
                      </td>

                      {/* Sub Total (Auto calculated) */}
                      <td className="py-2.5 px-3 text-right font-mono font-extrabold text-slate-900 bg-sky-50/60">
                        {calc ? formatCurrency(calc.subTotal) : '₹0.00'}
                      </td>

                      {/* Delete */}
                      <td className="py-2.5 px-2 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteRow(row.id)}
                          className="text-slate-400 hover:text-rose-600 p-1 transition-colors"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>

              {/* Table Footer: Aggregated Totals */}
              <tfoot className="bg-slate-900 text-white font-semibold border-t-2 border-slate-700">
                <tr>
                  <td colSpan={2} className="py-3 px-3 text-right uppercase tracking-wider text-xs font-bold text-slate-300">
                    Grand Totals:
                  </td>
                  <td className="py-3 px-2 font-mono text-center text-amber-300 font-bold">
                    {totals.totalBoxes} bxs
                  </td>
                  <td colSpan={2} className="py-3 px-2 text-center text-slate-400 text-[11px]">
                    —
                  </td>
                  <td className="py-3 px-2 font-mono font-bold text-slate-200">
                    {totals.totalGrossWeight.toFixed(3)} kg
                  </td>
                  <td className="py-3 px-2 font-mono text-amber-400">
                    - {totals.totalLessWeight.toFixed(3)} kg
                  </td>
                  <td className="py-3 px-2 font-mono font-extrabold text-emerald-300">
                    {totals.totalWeightAfterLess.toFixed(3)} kg
                  </td>
                  <td className="py-3 px-2 text-right text-slate-400 text-xs">
                    FINAL TOTAL:
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-black text-amber-400 text-sm sm:text-base">
                    {formatCurrency(totals.finalInvoiceTotal)}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>

          <div className="bg-slate-50 px-4 py-2.5 flex items-center justify-between border-t border-slate-200">
            <button
              type="button"
              onClick={handleAddRow}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-100 hover:bg-sky-200 text-sky-800 text-xs font-bold transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Another Item Row</span>
            </button>
            <span className="text-xs text-slate-500">
              {rows.length} {rows.length === 1 ? 'item' : 'items'} in transaction
            </span>
          </div>
        </div>

        {/* Optional details: Vehicle, Notes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-1.5">
              <Truck className="w-3.5 h-3.5 text-sky-600" />
              <span>Transport / Vehicle Number (Optional)</span>
            </label>
            <input
              type="text"
              value={vehicleNumber}
              onChange={e => setVehicleNumber(e.target.value)}
              placeholder="e.g. KA-01-AB-1234 / Lorry Name"
              className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium"
            />
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 block">
              Notes / Dispatch Instructions (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Consignment passed inspection, packing grade A"
              className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium"
            />
          </div>
        </div>

        {/* Final Submission Card */}
        <div className="bg-gradient-to-r from-slate-900 to-sky-950 text-white p-5 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg">
          <div>
            <div className="text-xs text-sky-300 uppercase tracking-widest font-bold">
              Aggregated Invoice Total
            </div>
            <div className="text-2xl sm:text-3xl font-black text-amber-400 mt-0.5">
              {formatCurrency(totals.finalInvoiceTotal)}
            </div>
            <div className="text-xs text-slate-300 mt-1">
              Net Weight: {totals.totalWeightAfterLess.toFixed(3)} kg ({totals.totalBoxes} Boxes)
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 sm:flex-initial px-5 py-2.5 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-300 text-sm font-semibold transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-sm font-extrabold shadow-lg shadow-amber-500/20 transition-all active:scale-95"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Save & Generate Invoice</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
