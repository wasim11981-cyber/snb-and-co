import React, { useState } from 'react';
import { 
  Boxes, 
  Search, 
  TrendingUp, 
  TrendingDown, 
  Scale, 
  AlertCircle, 
  Clock, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Sparkles 
} from 'lucide-react';
import { InventoryItem, Transaction } from '../types';
import { formatCurrency, formatDate, formatWeight } from '../utils/formatters';

interface InventoryViewProps {
  inventory: InventoryItem[];
  transactions: Transaction[];
  onOpenNewTransaction: (type: 'GIVE_STOCK' | 'TAKE_STOCK') => void;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  inventory,
  transactions,
  onOpenNewTransaction,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedItemName, setSelectedItemName] = useState<string | null>(null);

  const filteredItems = inventory.filter(i =>
    i.itemName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalBoxes = inventory.reduce((sum, i) => sum + i.totalBoxesInStock, 0);
  const totalWeight = inventory.reduce((sum, i) => sum + i.totalNetWeightKg, 0);
  const totalValuation = inventory.reduce(
    (sum, i) => sum + Math.max(0, i.totalNetWeightKg * i.averageRate),
    0
  );

  // Movements for selected item or recent items
  const recentMovements = transactions
    .flatMap(tx =>
      tx.items.map(item => ({
        txId: tx.id,
        invoiceNumber: tx.invoiceNumber,
        date: tx.date,
        type: tx.type,
        companyName: tx.companyName,
        itemName: item.itemName,
        boxes: item.boxes,
        weightAfterLess: item.weightAfterLess,
        rate: item.rate,
        subTotal: item.subTotal,
      }))
    )
    .filter(m => !selectedItemName || m.itemName.toLowerCase() === selectedItemName.toLowerCase())
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 10);

  return (
    <div className="space-y-6">
      {/* Top Metrics Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Stock Weight */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Total In-Stock Net Weight
            </div>
            <div className="text-2xl font-black text-slate-900 mt-1">
              {formatWeight(totalWeight)}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Real-time weighed & verified</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-sky-50 text-sky-600 border border-sky-200 flex items-center justify-center">
            <Scale className="w-6 h-6" />
          </div>
        </div>

        {/* Total Boxes In Warehouse */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Total In-Stock Boxes
            </div>
            <div className="text-2xl font-black text-amber-600 mt-1">
              {totalBoxes} Boxes
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Across all commodities</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center">
            <Boxes className="w-6 h-6" />
          </div>
        </div>

        {/* Total Inventory Valuation */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Estimated Stock Valuation
            </div>
            <div className="text-2xl font-black text-emerald-700 mt-1">
              {formatCurrency(totalValuation)}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">At prevailing market rates</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Stock Table and Recent Movement */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Real-time Item Inventory Table */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Boxes className="w-5 h-5 text-sky-600" />
                <span>Real-Time Warehouse Stock Ledger</span>
              </h3>
              <p className="text-xs text-slate-500">
                Automatically updated with every Inward (Take Stock) and Outward (Give Stock) transaction
              </p>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Search commodity / item..."
                className="pl-9 pr-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-sky-500"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Commodity / Item Name</th>
                  <th className="py-3 px-3 text-center">Boxes In Stock</th>
                  <th className="py-3 px-3 text-right">Net Weight (kg)</th>
                  <th className="py-3 px-3 text-right">Avg Rate (₹)</th>
                  <th className="py-3 px-4 text-right">Estimated Value (₹)</th>
                  <th className="py-3 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredItems.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400 italic">
                      No matching stock items found in warehouse.
                    </td>
                  </tr>
                ) : (
                  filteredItems.map(item => {
                    const isLow = item.totalBoxesInStock <= 5;
                    const valuation = item.totalNetWeightKg * item.averageRate;
                    const isSelected = selectedItemName === item.itemName;

                    return (
                      <tr
                        key={item.itemName}
                        onClick={() =>
                          setSelectedItemName(isSelected ? null : item.itemName)
                        }
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-sky-50/80 font-medium' : 'hover:bg-slate-50/80'
                        }`}
                      >
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900 flex items-center gap-2">
                            <span>{item.itemName}</span>
                            {isSelected && (
                              <span className="text-[10px] bg-sky-600 text-white px-1.5 py-0.5 rounded font-bold">
                                Selected
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-slate-400">
                            {item.stockHistoryCount} transaction {item.stockHistoryCount === 1 ? 'batch' : 'batches'}
                          </span>
                        </td>

                        <td className="py-3.5 px-3 text-center font-mono font-bold text-slate-800">
                          {item.totalBoxesInStock} bxs
                        </td>

                        <td className="py-3.5 px-3 text-right font-mono font-extrabold text-slate-900">
                          {formatWeight(item.totalNetWeightKg)}
                        </td>

                        <td className="py-3.5 px-3 text-right font-mono text-slate-700">
                          ₹{item.averageRate.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </td>

                        <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-800">
                          {formatCurrency(valuation)}
                        </td>

                        <td className="py-3.5 px-3 text-center">
                          {isLow ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                              <AlertCircle className="w-3 h-3" />
                              Low
                            </span>
                          ) : (
                            <span className="inline-flex items-center text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                              In Stock
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
            <span className="text-slate-500">
              Click any item row to view its specific movement ledger
            </span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => onOpenNewTransaction('TAKE_STOCK')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg font-bold"
              >
                <ArrowDownLeft className="w-3.5 h-3.5" />
                <span>+ Stock Inward (Take)</span>
              </button>
              <button
                type="button"
                onClick={() => onOpenNewTransaction('GIVE_STOCK')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold"
              >
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>- Stock Outward (Give)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Live Stock In/Out Movement History */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-3">
              <div>
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-sky-600" />
                  <span>Stock Movement Feed</span>
                </h4>
                <p className="text-[11px] text-slate-500">
                  {selectedItemName ? `Filtered for ${selectedItemName}` : 'Latest warehouse dispatches & receipts'}
                </p>
              </div>
              {selectedItemName && (
                <button
                  type="button"
                  onClick={() => setSelectedItemName(null)}
                  className="text-[11px] text-sky-600 font-bold hover:underline"
                >
                  Clear filter
                </button>
              )}
            </div>

            <div className="space-y-3 overflow-y-auto max-h-[460px]">
              {recentMovements.length === 0 ? (
                <p className="text-center text-slate-400 text-xs py-8 italic">
                  No stock movements recorded for this item.
                </p>
              ) : (
                recentMovements.map((m, idx) => (
                  <div
                    key={`${m.txId}-${idx}`}
                    className="p-3 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-slate-100 transition-colors text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className={`inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded text-[10px] ${
                        m.type === 'GIVE_STOCK'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {m.type === 'GIVE_STOCK' ? 'OUT (Given)' : 'IN (Taken)'}
                      </span>
                      <span className="text-[11px] font-mono text-slate-500">
                        {formatDate(m.date)}
                      </span>
                    </div>

                    <div className="font-bold text-slate-900 mt-1.5 text-xs">
                      {m.itemName}
                    </div>

                    <div className="text-[11px] text-slate-600 mt-0.5">
                      Company: <span className="font-semibold text-slate-800">{m.companyName}</span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] font-mono mt-2 pt-2 border-t border-slate-200/80">
                      <span className="text-slate-600 font-medium">
                        {m.boxes} bxs &bull; {m.weightAfterLess.toFixed(2)} kg
                      </span>
                      <span className="font-bold text-slate-900">
                        {formatCurrency(m.subTotal)}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
