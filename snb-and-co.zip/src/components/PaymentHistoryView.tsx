import React, { useState } from 'react';
import { 
  CreditCard, 
  Search, 
  Filter, 
  ArrowDownLeft, 
  ArrowUpRight, 
  PlusCircle, 
  Calendar, 
  Building2, 
  Receipt 
} from 'lucide-react';
import { Company, Payment } from '../types';
import { formatCurrency, formatDate } from '../utils/formatters';

interface PaymentHistoryViewProps {
  payments: Payment[];
  companies: Company[];
  onOpenPaymentModal: (companyId?: string) => void;
  onOpenLedger: (companyId: string) => void;
}

export const PaymentHistoryView: React.FC<PaymentHistoryViewProps> = ({
  payments,
  companies,
  onOpenPaymentModal,
  onOpenLedger,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>('ALL');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'RECEIVED' | 'PAID'>('ALL');

  const filteredPayments = payments
    .filter(p => {
      if (selectedCompanyId !== 'ALL' && p.companyId !== selectedCompanyId) return false;
      if (typeFilter === 'RECEIVED' && p.type !== 'PAYMENT_RECEIVED') return false;
      if (typeFilter === 'PAID' && p.type !== 'PAYMENT_PAID') return false;
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        return (
          p.companyName.toLowerCase().includes(term) ||
          p.receiptNumber.toLowerCase().includes(term) ||
          (p.referenceNumber && p.referenceNumber.toLowerCase().includes(term)) ||
          (p.notes && p.notes.toLowerCase().includes(term))
        );
      }
      return true;
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const totalReceived = payments
    .filter(p => p.type === 'PAYMENT_RECEIVED')
    .reduce((sum, p) => sum + p.amount, 0);

  const totalPaid = payments
    .filter(p => p.type === 'PAYMENT_PAID')
    .reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="space-y-6">
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Payments Received */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Total Inward Collections (Received)
            </div>
            <div className="text-2xl font-black text-emerald-700 mt-1">
              {formatCurrency(totalReceived)}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">From clients given stock</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center">
            <ArrowDownLeft className="w-6 h-6" />
          </div>
        </div>

        {/* Total Payments Paid Out */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Total Outward Payments (Paid)
            </div>
            <div className="text-2xl font-black text-rose-700 mt-1">
              {formatCurrency(totalPaid)}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">To suppliers taken stock</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 border border-rose-200 flex items-center justify-center">
            <ArrowUpRight className="w-6 h-6" />
          </div>
        </div>

        {/* Net Cashflow Balance */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Net Financial Cashflow
            </div>
            <div className={`text-2xl font-black mt-1 ${totalReceived - totalPaid >= 0 ? 'text-sky-700' : 'text-amber-700'}`}>
              {formatCurrency(totalReceived - totalPaid)}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Inflow minus Outflow</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-sky-50 text-sky-600 border border-sky-200 flex items-center justify-center">
            <Receipt className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Controls Bar */}
        <div className="p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-amber-600" />
              <span>Client Payment & Settlement History</span>
            </h3>
            <p className="text-xs text-slate-500">
              Complete audit trail of all receipts and disbursements
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Filter by Type */}
            <div className="flex bg-slate-100 p-1 rounded-lg text-xs font-bold">
              <button
                type="button"
                onClick={() => setTypeFilter('ALL')}
                className={`px-3 py-1 rounded-md transition-all ${
                  typeFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setTypeFilter('RECEIVED')}
                className={`px-3 py-1 rounded-md transition-all ${
                  typeFilter === 'RECEIVED' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Received
              </button>
              <button
                type="button"
                onClick={() => setTypeFilter('PAID')}
                className={`px-3 py-1 rounded-md transition-all ${
                  typeFilter === 'PAID' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Paid
              </button>
            </div>

            {/* Filter by Company */}
            <select
              value={selectedCompanyId}
              onChange={e => setSelectedCompanyId(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-sky-500"
            >
              <option value="ALL">All Companies</option>
              {companies.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>

            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Search payments..."
                className="pl-9 pr-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <button
              type="button"
              onClick={() => onOpenPaymentModal()}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg shadow-sm transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Record New Payment</span>
            </button>
          </div>
        </div>

        {/* Payments Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 w-28">Date</th>
                <th className="py-3 px-3 w-32 font-mono">Receipt #</th>
                <th className="py-3 px-4">Company / Client Name</th>
                <th className="py-3 px-3 text-center">Direction</th>
                <th className="py-3 px-3">Payment Mode</th>
                <th className="py-3 px-3 font-mono">Ref / Cheque #</th>
                <th className="py-3 px-4 text-right font-bold text-slate-800">Amount (₹)</th>
                <th className="py-3 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 italic">
                    No payment records found matching the filters.
                  </td>
                </tr>
              ) : (
                filteredPayments.map(p => {
                  const isReceived = p.type === 'PAYMENT_RECEIVED';

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-700 whitespace-nowrap">
                        {formatDate(p.date)}
                      </td>
                      <td className="py-3 px-3 font-mono font-bold text-slate-700">
                        {p.receiptNumber}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{p.companyName}</div>
                        {p.notes && (
                          <div className="text-[11px] text-slate-500 italic mt-0.5">
                            {p.notes}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          isReceived
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-rose-100 text-rose-800 border border-rose-200'
                        }`}>
                          {isReceived ? (
                            <>
                              <ArrowDownLeft className="w-3 h-3" /> Received
                            </>
                          ) : (
                            <>
                              <ArrowUpRight className="w-3 h-3" /> Paid Out
                            </>
                          )}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-700">
                        {p.paymentMethod.replace('_', ' ')}
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-600">
                        {p.referenceNumber || '—'}
                      </td>
                      <td className={`py-3 px-4 text-right font-mono font-black text-sm ${
                        isReceived ? 'text-emerald-700' : 'text-rose-700'
                      }`}>
                        {formatCurrency(p.amount)}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => onOpenLedger(p.companyId)}
                          className="text-sky-700 hover:text-sky-900 font-bold hover:underline"
                        >
                          View Ledger
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
