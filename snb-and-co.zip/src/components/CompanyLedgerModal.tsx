import React, { useState } from 'react';
import { 
  Building2, 
  Phone, 
  MapPin, 
  Calendar, 
  TrendingUp, 
  TrendingDown, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Receipt, 
  CreditCard, 
  Printer, 
  X, 
  FileText,
  Filter
} from 'lucide-react';
import { Company, LedgerEntry, Transaction } from '../types';
import { getCompanyLedger } from '../utils/storage';
import { formatCurrency, formatDate } from '../utils/formatters';

interface CompanyLedgerModalProps {
  company: Company;
  transactions: Transaction[];
  onClose: () => void;
  onOpenNewTransaction: (type: 'GIVE_STOCK' | 'TAKE_STOCK', companyId: string) => void;
  onOpenPaymentModal: (companyId: string) => void;
  onViewInvoice: (transaction: Transaction) => void;
}

export const CompanyLedgerModal: React.FC<CompanyLedgerModalProps> = ({
  company,
  transactions,
  onClose,
  onOpenNewTransaction,
  onOpenPaymentModal,
  onViewInvoice,
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');

  const { entries, totalDebit, totalCredit, netBalance, balanceType } = getCompanyLedger(company.id);

  const filteredEntries = entries.filter(entry => {
    if (filterType === 'ALL') return true;
    if (filterType === 'STOCK') return entry.type === 'GIVE_STOCK' || entry.type === 'TAKE_STOCK';
    if (filterType === 'PAYMENTS') return entry.type === 'PAYMENT_RECEIVED' || entry.type === 'PAYMENT_PAID';
    return entry.type === filterType;
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 flex flex-col max-h-[92vh]">
        {/* Header Bar */}
        <div className="no-print bg-slate-900 text-white px-6 py-4 flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold">{company.name}</h2>
                <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                  {company.id}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Official Account Ledger & Balance Auto-Calculation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Statement</span>
            </button>

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Client Profile and Balance Status Ribbon */}
        <div className="p-6 bg-slate-50 border-b border-slate-200">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Left: Client Contact Details */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 text-xs space-y-1.5 shadow-sm">
              <div className="font-bold text-slate-800 text-sm mb-2 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-sky-600" />
                <span>Client Profile</span>
              </div>
              <p className="text-slate-600 flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                <span>{company.phone || 'No phone'}</span>
              </p>
              <p className="text-slate-600 flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                <span className="line-clamp-2">{company.address || 'Address not listed'}</span>
              </p>
              {company.gstNumber && (
                <p className="text-slate-600 font-mono text-[11px]">
                  GSTIN: {company.gstNumber}
                </p>
              )}
            </div>

            {/* Middle: Auto-Calculated Balance Box */}
            <div className={`p-4 rounded-xl border shadow-sm flex flex-col justify-between ${
              balanceType === 'RECEIVABLE'
                ? 'bg-emerald-50/70 border-emerald-300'
                : balanceType === 'PAYABLE'
                ? 'bg-rose-50/70 border-rose-300'
                : 'bg-slate-100 border-slate-200'
            }`}>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Current Net Auto-Balance
                </span>
                <div className={`text-2xl font-black mt-1 ${
                  balanceType === 'RECEIVABLE'
                    ? 'text-emerald-700'
                    : balanceType === 'PAYABLE'
                    ? 'text-rose-700'
                    : 'text-slate-700'
                }`}>
                  {formatCurrency(Math.abs(netBalance))}
                </div>
              </div>

              <div className="mt-2 text-xs font-bold">
                {balanceType === 'RECEIVABLE' && (
                  <span className="inline-flex items-center gap-1 text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                    <TrendingUp className="w-3.5 h-3.5" />
                    RECEIVABLE (Client owes SNB AND CO)
                  </span>
                )}
                {balanceType === 'PAYABLE' && (
                  <span className="inline-flex items-center gap-1 text-rose-800 bg-rose-100 px-2 py-0.5 rounded">
                    <TrendingDown className="w-3.5 h-3.5" />
                    PAYABLE (SNB AND CO owes Client)
                  </span>
                )}
                {balanceType === 'SETTLED' && (
                  <span className="text-slate-600 bg-slate-200 px-2 py-0.5 rounded">
                    All Transactions Fully Settled
                  </span>
                )}
              </div>
            </div>

            {/* Right: Quick Actions */}
            <div className="no-print bg-white p-4 rounded-xl border border-slate-200 flex flex-col justify-center gap-2 shadow-sm">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                Client Quick Actions
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onOpenNewTransaction('GIVE_STOCK', company.id)}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all"
                >
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  <span>Give Stock</span>
                </button>
                <button
                  type="button"
                  onClick={() => onOpenNewTransaction('TAKE_STOCK', company.id)}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-all"
                >
                  <ArrowDownLeft className="w-3.5 h-3.5" />
                  <span>Take Stock</span>
                </button>
              </div>
              <button
                type="button"
                onClick={() => onOpenPaymentModal(company.id)}
                className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-sm transition-all"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>Record Payment (In / Out)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Ledger Filter Toolbar */}
        <div className="no-print px-6 py-3 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="font-bold text-slate-600">Filter Ledger:</span>
            {['ALL', 'STOCK', 'PAYMENTS'].map(t => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                className={`px-3 py-1 rounded-md font-semibold transition-all ${
                  filterType === t
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-200'
                }`}
              >
                {t === 'ALL' ? 'All Entries' : t === 'STOCK' ? 'Stocks Only' : 'Payments Only'}
              </button>
            ))}
          </div>

          <div className="text-slate-500 font-medium">
            Showing {filteredEntries.length} chronological ledger entries
          </div>
        </div>

        {/* Ledger Statement Table */}
        <div className="p-6 overflow-y-auto flex-1 bg-white">
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-900 text-white font-bold">
                <tr>
                  <th className="py-3 px-3 w-28">Date</th>
                  <th className="py-3 px-3">Particulars & Reference</th>
                  <th className="py-3 px-2 w-28 font-mono">Doc #</th>
                  <th className="py-3 px-3 w-32 text-right text-emerald-300">Debit (Dr) ₹</th>
                  <th className="py-3 px-3 w-32 text-right text-rose-300">Credit (Cr) ₹</th>
                  <th className="py-3 px-3 w-36 text-right font-mono bg-slate-800 text-amber-300 font-extrabold">
                    Balance ₹
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredEntries.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400 italic">
                      No ledger transactions recorded yet for this filter.
                    </td>
                  </tr>
                ) : (
                  filteredEntries.map(item => {
                    const isDebit = item.debit > 0;
                    const isCredit = item.credit > 0;
                    const tx = transactions.find(t => t.id === item.referenceId);

                    return (
                      <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                        {/* Date */}
                        <td className="py-3 px-3 font-medium text-slate-700 whitespace-nowrap">
                          {formatDate(item.date)}
                        </td>

                        {/* Particulars */}
                        <td className="py-3 px-3">
                          <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                            {item.type === 'GIVE_STOCK' && (
                              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                            )}
                            {item.type === 'TAKE_STOCK' && (
                              <span className="w-2 h-2 rounded-full bg-sky-500 inline-block" />
                            )}
                            {item.type.startsWith('PAYMENT') && (
                              <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
                            )}
                            <span>{item.particulars}</span>
                          </div>
                          {item.notes && (
                            <p className="text-[11px] text-slate-500 italic mt-0.5">
                              {item.notes}
                            </p>
                          )}
                        </td>

                        {/* Doc Number */}
                        <td className="py-3 px-2 font-mono text-slate-700">
                          {tx ? (
                            <button
                              type="button"
                              onClick={() => onViewInvoice(tx)}
                              className="text-sky-700 hover:text-sky-900 hover:underline font-bold flex items-center gap-1"
                              title="Click to view full Invoice"
                            >
                              <FileText className="w-3.5 h-3.5" />
                              <span>{item.referenceDocNo}</span>
                            </button>
                          ) : (
                            <span>{item.referenceDocNo}</span>
                          )}
                        </td>

                        {/* Debit */}
                        <td className="py-3 px-3 text-right font-mono font-bold text-emerald-700">
                          {isDebit ? formatCurrency(item.debit) : '—'}
                        </td>

                        {/* Credit */}
                        <td className="py-3 px-3 text-right font-mono font-bold text-rose-700">
                          {isCredit ? formatCurrency(item.credit) : '—'}
                        </td>

                        {/* Running Balance */}
                        <td className="py-3 px-3 text-right font-mono font-black bg-slate-50 text-slate-900">
                          {formatCurrency(Math.abs(item.runningBalance))}
                          <span className={`ml-1 text-[10px] font-bold ${
                            item.runningBalance > 0 ? 'text-emerald-700' : item.runningBalance < 0 ? 'text-rose-700' : 'text-slate-500'
                          }`}>
                            {item.runningBalance > 0 ? 'Dr' : item.runningBalance < 0 ? 'Cr' : ''}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>

              {/* Aggregated Totals Footer */}
              <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300">
                <tr>
                  <td colSpan={3} className="py-3 px-3 text-right uppercase tracking-wider text-xs text-slate-700">
                    Grand Statement Totals:
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-black text-emerald-800">
                    {formatCurrency(totalDebit)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-black text-rose-800">
                    {formatCurrency(totalCredit)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-black text-sm bg-amber-100 text-slate-950">
                    {formatCurrency(Math.abs(netBalance))} {netBalance > 0 ? 'Dr' : netBalance < 0 ? 'Cr' : ''}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="no-print bg-slate-50 px-6 py-3.5 border-t border-slate-200 flex justify-between items-center text-xs">
          <span className="text-slate-500">
            Auto-calculated according to SNB AND CO Ledger Principles
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold transition-all"
          >
            Close Statement
          </button>
        </div>
      </div>
    </div>
  );
};
