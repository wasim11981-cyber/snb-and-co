import React, { useState } from 'react';
import { 
  CreditCard, 
  X, 
  CheckCircle2, 
  Building2, 
  Calendar, 
  DollarSign, 
  FileText 
} from 'lucide-react';
import { Company, Payment, PaymentMethod, PaymentType } from '../types';
import { generateNextNumber } from '../utils/storage';

interface PaymentModalProps {
  companies: Company[];
  initialCompanyId?: string;
  onSave: (payment: Payment) => void;
  onClose: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  companies,
  initialCompanyId,
  onSave,
  onClose,
}) => {
  const [companyId, setCompanyId] = useState<string>(initialCompanyId || (companies[0]?.id || ''));
  const [type, setType] = useState<PaymentType>('PAYMENT_RECEIVED');
  const [amount, setAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('BANK_TRANSFER');
  const [referenceNumber, setReferenceNumber] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [errorMsg, setErrorMsg] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyId) {
      setErrorMsg('Please select a company.');
      return;
    }
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setErrorMsg('Please enter a valid payment amount greater than zero.');
      return;
    }

    const comp = companies.find(c => c.id === companyId);
    if (!comp) {
      setErrorMsg('Company not found.');
      return;
    }

    const payment: Payment = {
      id: `pay-${Date.now()}`,
      receiptNumber: generateNextNumber(type === 'PAYMENT_RECEIVED' ? 'RCP' : 'VCH'),
      companyId: comp.id,
      companyName: comp.name,
      type,
      amount: numAmount,
      paymentMethod,
      referenceNumber: referenceNumber.trim(),
      notes: notes.trim(),
      date,
      createdAt: new Date().toISOString(),
    };

    onSave(payment);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold">Record Payment</h3>
              <p className="text-xs text-slate-400">Updates client ledger balance instantly</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMsg && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-3 rounded-lg text-xs">
              {errorMsg}
            </div>
          )}

          {/* Payment Type Selection */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1.5">
              Payment Direction *
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setType('PAYMENT_RECEIVED')}
                className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all ${
                  type === 'PAYMENT_RECEIVED'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Received (From Client)
              </button>
              <button
                type="button"
                onClick={() => setType('PAYMENT_PAID')}
                className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all ${
                  type === 'PAYMENT_PAID'
                    ? 'bg-rose-50 border-rose-500 text-rose-800 ring-2 ring-rose-500/20'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Paid (To Client / Supplier)
              </button>
            </div>
          </div>

          {/* Company Selection */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-1.5">
              <Building2 className="w-3.5 h-3.5 text-sky-600" />
              <span>Select Company *</span>
            </label>
            <select
              value={companyId}
              onChange={e => setCompanyId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-medium focus:ring-2 focus:ring-sky-500"
              required
            >
              <option value="">-- Choose Company --</option>
              {companies.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Amount */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1.5">
              Amount (₹) *
            </label>
            <input
              type="number"
              step="any"
              min="0.01"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="e.g. 50000"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-base font-bold font-mono focus:ring-2 focus:ring-sky-500"
              required
            />
          </div>

          {/* Payment Method & Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1.5">
                Payment Mode
              </label>
              <select
                value={paymentMethod}
                onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-sky-500"
              >
                <option value="BANK_TRANSFER">Bank / NEFT / RTGS</option>
                <option value="UPI">UPI / QR</option>
                <option value="CASH">Cash</option>
                <option value="CHEQUE">Cheque</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1 mb-1.5">
                <Calendar className="w-3.5 h-3.5 text-sky-600" />
                <span>Date</span>
              </label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-sky-500"
                required
              />
            </div>
          </div>

          {/* Reference Number */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1.5">
              Reference / Cheque / UTR No (Optional)
            </label>
            <input
              type="text"
              value={referenceNumber}
              onChange={e => setReferenceNumber(e.target.value)}
              placeholder="e.g. UTR-9948214 or Chq #004312"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-medium focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1.5">
              Notes / Particulars (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Settlement against Inv SNB-OUT-0201"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Actions */}
          <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg shadow-sm transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Record & Update Ledger</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
