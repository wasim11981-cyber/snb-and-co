import React from 'react';
import { 
  Printer, 
  Share2, 
  X, 
  Check, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Building2, 
  Phone, 
  MapPin, 
  Calendar 
} from 'lucide-react';
import { Transaction } from '../types';
import { formatCurrency, formatDate, formatWeight, numberToWords } from '../utils/formatters';

interface InvoiceModalProps {
  transaction: Transaction;
  onClose: () => void;
  onOpenLedger?: (companyId: string) => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({
  transaction,
  onClose,
  onOpenLedger,
}) => {
  const [copied, setCopied] = React.useState(false);

  const isGiveStock = transaction.type === 'GIVE_STOCK';

  const handlePrint = () => {
    window.print();
  };

  const handleCopyText = () => {
    const text = `
=== SNB AND CO ===
${isGiveStock ? 'TAX INVOICE / STOCK DELIVERY CHALLAN' : 'INWARD PURCHASE BILL / STOCK RECEIPT'}
Invoice No: ${transaction.invoiceNumber}
Date: ${formatDate(transaction.date)}
Party: ${transaction.companyName}
${transaction.vehicleNumber ? `Vehicle: ${transaction.vehicleNumber}` : ''}

ITEMS:
${transaction.items
  .map(
    (i, idx) =>
      `${idx + 1}. ${i.itemName} | ${i.boxes} bxs * ${i.weightPerBox}kg + ${i.looseWeight}kg loose = ${i.totalWeight}kg | Less 5% (-${i.lessWeight}kg) = ${i.weightAfterLess}kg @ ₹${i.rate}/kg = ₹${i.subTotal.toLocaleString('en-IN')}`
  )
  .join('\n')}

TOTALS:
Total Boxes: ${transaction.totalBoxes}
Gross Weight: ${transaction.totalGrossWeight} kg
Less (5%): -${transaction.totalLessWeight} kg
Net Weight: ${transaction.totalWeightAfterLess} kg
FINAL INVOICE TOTAL: ${formatCurrency(transaction.finalInvoiceTotal)}
Amount in Words: ${numberToWords(transaction.finalInvoiceTotal)}
    `.trim();

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 flex flex-col max-h-[92vh]">
        {/* Modal Top Actions (Hidden in Print) */}
        <div className="no-print bg-slate-900 text-white px-6 py-3.5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold ${
              isGiveStock ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
            }`}>
              {isGiveStock ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownLeft className="w-3.5 h-3.5" />}
              {isGiveStock ? 'Outward Stock Invoice' : 'Inward Stock Note'}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {transaction.invoiceNumber}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyText}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Summary'}</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow transition-all"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Document */}
        <div id="printable-invoice" className="p-6 sm:p-8 overflow-y-auto flex-1 bg-white text-slate-900 font-sans">
          {/* Company Brand Header */}
          <div className="border-b-2 border-slate-900 pb-5 mb-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-lg bg-slate-900 text-amber-400 flex items-center justify-center font-black text-xl tracking-wider">
                    SNB
                  </div>
                  <div>
                    <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900">
                      SNB AND CO
                    </h1>
                    <p className="text-xs font-semibold text-slate-600 tracking-wide uppercase">
                      Wholesale Stock Trading, Commodity Commission & Logistics
                    </p>
                  </div>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  Head Office: Wholesale Commodity Exchange, APMC Yard, Main Market Road
                </p>
                <p className="text-xs text-slate-500">
                  Contact: +91 98765 43210 / +91 94432 10987 &bull; GSTIN: 29AAAFS1234F1Z8
                </p>
              </div>

              {/* Document Type Badge */}
              <div className="text-left sm:text-right border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-200">
                <span className={`inline-block px-3 py-1 rounded text-xs font-extrabold uppercase tracking-wider ${
                  isGiveStock ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' : 'bg-sky-100 text-sky-900 border border-sky-300'
                }`}>
                  {isGiveStock ? 'TAX INVOICE / STOCK DELIVERY' : 'STOCK INWARD PURCHASE NOTE'}
                </span>
                <div className="text-sm font-mono font-bold text-slate-800 mt-1">
                  #{transaction.invoiceNumber}
                </div>
                <div className="text-xs text-slate-500 flex items-center sm:justify-end gap-1 mt-0.5">
                  <Calendar className="w-3 h-3" />
                  <span>Date: {formatDate(transaction.date)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Billed Party & Transport Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 mb-6 text-xs">
            <div>
              <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px]">
                {isGiveStock ? 'Customer / Consignee Details (Billed To):' : 'Supplier / Consignor Details (Received From):'}
              </span>
              <div className="text-sm font-extrabold text-slate-900 mt-1 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-sky-700" />
                <span>{transaction.companyName}</span>
              </div>
              <div className="text-slate-600 mt-1">
                Account ID: <span className="font-mono text-slate-800">{transaction.companyId}</span>
              </div>
              {onOpenLedger && (
                <button
                  type="button"
                  onClick={() => onOpenLedger(transaction.companyId)}
                  className="no-print mt-2 text-xs font-bold text-sky-700 hover:text-sky-900 underline"
                >
                  View Client Statement of Account &rarr;
                </button>
              )}
            </div>

            <div className="border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-200 sm:border-l sm:pl-4">
              <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px]">
                Logistics & Reference
              </span>
              <div className="text-slate-700 mt-1">
                <span className="font-medium">Vehicle / Lorry No:</span>{' '}
                <span className="font-mono font-bold text-slate-900">{transaction.vehicleNumber || 'Self / Local Delivery'}</span>
              </div>
              <div className="text-slate-700 mt-0.5">
                <span className="font-medium">Transaction Type:</span>{' '}
                <span className="font-semibold text-slate-900">
                  {isGiveStock ? 'Outward Stock (Sales / Delivery)' : 'Inward Stock (Purchase / Intake)'}
                </span>
              </div>
              {transaction.notes && (
                <div className="text-slate-600 mt-1 italic">
                  Note: {transaction.notes}
                </div>
              )}
            </div>
          </div>

          {/* Line Items Table with exact calculation logic */}
          <div className="border border-slate-300 rounded-lg overflow-hidden mb-6">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-800 text-white font-bold border-b border-slate-400">
                  <th className="py-2.5 px-2 text-center w-8">#</th>
                  <th className="py-2.5 px-3">Item Description</th>
                  <th className="py-2.5 px-2 text-center">Boxes</th>
                  <th className="py-2.5 px-2 text-right">Box Wt (kg)</th>
                  <th className="py-2.5 px-2 text-right">Loose Wt</th>
                  <th className="py-2.5 px-2 text-right bg-slate-700/60 font-mono">Gross Wt</th>
                  <th className="py-2.5 px-2 text-right text-amber-300">Less (5%)</th>
                  <th className="py-2.5 px-2 text-right bg-slate-700/60 font-mono font-extrabold text-emerald-300">Net Wt</th>
                  <th className="py-2.5 px-2 text-right">Rate (₹)</th>
                  <th className="py-2.5 px-3 text-right font-extrabold bg-slate-900 text-amber-300">Sub Total (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {transaction.items.map((item, idx) => (
                  <tr key={item.id || idx} className="hover:bg-slate-50">
                    <td className="py-2 px-2 text-center font-bold text-slate-500">
                      {idx + 1}
                    </td>
                    <td className="py-2 px-3 font-semibold text-slate-900">
                      {item.itemName}
                    </td>
                    <td className="py-2 px-2 text-center font-mono font-medium">
                      {item.boxes}
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-slate-700">
                      {item.weightPerBox.toFixed(2)}
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-slate-700">
                      {item.looseWeight.toFixed(2)}
                    </td>
                    <td className="py-2 px-2 text-right font-mono font-bold text-slate-800 bg-slate-50">
                      {item.totalWeight.toFixed(3)}
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-amber-700">
                      -{item.lessWeight.toFixed(3)}
                    </td>
                    <td className="py-2 px-2 text-right font-mono font-bold text-emerald-800 bg-emerald-50/40">
                      {item.weightAfterLess.toFixed(3)}
                    </td>
                    <td className="py-2 px-2 text-right font-mono font-medium text-slate-800">
                      ₹{item.rate.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-2 px-3 text-right font-mono font-black text-slate-900 bg-slate-50">
                      {formatCurrency(item.subTotal)}
                    </td>
                  </tr>
                ))}
              </tbody>
              {/* Aggregated Totals Row */}
              <tfoot>
                <tr className="bg-slate-100 font-bold border-t-2 border-slate-300 text-slate-900">
                  <td colSpan={2} className="py-2.5 px-3 text-right uppercase tracking-wider text-xs">
                    Total:
                  </td>
                  <td className="py-2.5 px-2 text-center font-mono font-bold">
                    {transaction.totalBoxes}
                  </td>
                  <td colSpan={2} className="py-2.5 px-2 text-center text-slate-400">
                    —
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono font-bold text-slate-900">
                    {transaction.totalGrossWeight.toFixed(3)} kg
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono text-amber-700">
                    -{transaction.totalLessWeight.toFixed(3)} kg
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono font-extrabold text-emerald-800 bg-emerald-100/60">
                    {transaction.totalWeightAfterLess.toFixed(3)} kg
                  </td>
                  <td className="py-2.5 px-2 text-right text-xs uppercase tracking-wider text-slate-600">
                    INVOICE TOTAL:
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-black text-slate-950 text-sm bg-amber-100/80">
                    {formatCurrency(transaction.finalInvoiceTotal)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Amount In Words & Terms */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
            <div>
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Total Amount In Words:
              </div>
              <div className="text-sm font-serif font-bold text-slate-900 bg-slate-50 p-2.5 rounded-lg border border-slate-200 mt-1 italic">
                {numberToWords(transaction.finalInvoiceTotal)}
              </div>

              <div className="mt-4 text-[11px] text-slate-500 space-y-1">
                <p className="font-bold text-slate-700">Standard Trading Terms:</p>
                <p>1. Calculation applied: (Box × Wt + Loose) Less 5% Tare Deduction.</p>
                <p>2. Goods once delivered/accepted subject to standard APMC yard trade regulations.</p>
                <p>3. Please verify net weight at delivery gate.</p>
              </div>
            </div>

            {/* Signature Box */}
            <div className="flex flex-col justify-between items-end text-right pt-6 sm:pt-0">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                For SNB AND CO
              </div>
              <div className="pt-16 border-t border-slate-300 w-48 text-center text-xs text-slate-600 font-medium">
                Authorized Signatory / In-charge
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Close */}
        <div className="no-print bg-slate-50 px-6 py-3.5 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all"
          >
            Close Invoice
          </button>
        </div>
      </div>
    </div>
  );
};
