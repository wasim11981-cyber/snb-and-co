import React, { useState } from 'react';
import { 
  Building2, 
  Search, 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  CreditCard, 
  FileText, 
  Phone, 
  MapPin, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle2 
} from 'lucide-react';
import { Company, Transaction, Payment } from '../types';
import { getCompanyLedger } from '../utils/storage';
import { formatCurrency } from '../utils/formatters';

interface CompaniesLedgerViewProps {
  companies: Company[];
  transactions: Transaction[];
  payments: Payment[];
  onOpenLedger: (companyId: string) => void;
  onOpenNewTransaction: (type: 'GIVE_STOCK' | 'TAKE_STOCK', companyId?: string) => void;
  onOpenPaymentModal: (companyId?: string) => void;
  onAddNewCompany: () => void;
}

export const CompaniesLedgerView: React.FC<CompaniesLedgerViewProps> = ({
  companies,
  transactions,
  payments,
  onOpenLedger,
  onOpenNewTransaction,
  onOpenPaymentModal,
  onAddNewCompany,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [balanceFilter, setBalanceFilter] = useState<'ALL' | 'RECEIVABLE' | 'PAYABLE' | 'SETTLED'>('ALL');

  // Compute stats for each company
  const companyData = companies.map(comp => {
    const ledger = getCompanyLedger(comp.id);
    return {
      company: comp,
      ledger,
    };
  });

  const filteredCompanies = companyData.filter(({ company, ledger }) => {
    if (balanceFilter !== 'ALL' && ledger.balanceType !== balanceFilter) return false;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return (
        company.name.toLowerCase().includes(term) ||
        (company.contactPerson && company.contactPerson.toLowerCase().includes(term)) ||
        (company.phone && company.phone.toLowerCase().includes(term)) ||
        (company.address && company.address.toLowerCase().includes(term))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Header Controls */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Building2 className="w-6 h-6 text-sky-600" />
            <span>Client & Supplier Ledger Directory</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Auto-calculated balances based on Stock Deliveries (Give), Inward Receipts (Take), and Payments
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Balance Filter Pills */}
          <div className="flex bg-slate-100 p-1 rounded-lg text-xs font-bold">
            <button
              onClick={() => setBalanceFilter('ALL')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                balanceFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({companies.length})
            </button>
            <button
              onClick={() => setBalanceFilter('RECEIVABLE')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                balanceFilter === 'RECEIVABLE' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Receivables (Dr)
            </button>
            <button
              onClick={() => setBalanceFilter('PAYABLE')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                balanceFilter === 'PAYABLE' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Payables (Cr)
            </button>
          </div>

          {/* Search Bar */}
          <div className="relative min-w-[220px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search company or phone..."
              className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Add Company Button */}
          <button
            type="button"
            onClick={onAddNewCompany}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded-lg shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Company</span>
          </button>
        </div>
      </div>

      {/* Company Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredCompanies.length === 0 ? (
          <div className="col-span-full bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-400">
            <Building2 className="w-12 h-12 mx-auto text-slate-300 mb-3" />
            <p className="text-base font-semibold text-slate-600">No companies found</p>
            <p className="text-xs mt-1">Try adjusting your search terms or add a new client.</p>
          </div>
        ) : (
          filteredCompanies.map(({ company, ledger }) => {
            const isReceivable = ledger.balanceType === 'RECEIVABLE';
            const isPayable = ledger.balanceType === 'PAYABLE';

            return (
              <div
                key={company.id}
                className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow p-5 flex flex-col justify-between"
              >
                <div>
                  {/* Card Header: Company Name & Auto-Balance Badge */}
                  <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-100">
                    <div>
                      <h3 className="font-bold text-slate-900 text-base leading-tight">
                        {company.name}
                      </h3>
                      {company.contactPerson && (
                        <p className="text-xs text-slate-500 mt-0.5">
                          Attn: {company.contactPerson}
                        </p>
                      )}
                    </div>

                    <span className={`text-[11px] font-extrabold px-2.5 py-1 rounded-full shrink-0 ${
                      isReceivable
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : isPayable
                        ? 'bg-rose-100 text-rose-800 border border-rose-300'
                        : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}>
                      {isReceivable ? 'Receivable (Dr)' : isPayable ? 'Payable (Cr)' : 'Settled'}
                    </span>
                  </div>

                  {/* Auto-Calculated Balance Value */}
                  <div className="py-3 my-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                      Auto-Calculated Balance:
                    </span>
                    <div className={`text-2xl font-black mt-0.5 ${
                      isReceivable ? 'text-emerald-700' : isPayable ? 'text-rose-700' : 'text-slate-700'
                    }`}>
                      {formatCurrency(Math.abs(ledger.netBalance))}
                      <span className="text-xs font-bold text-slate-500 ml-1.5">
                        {isReceivable ? '(Client Owes SNB)' : isPayable ? '(SNB Owes Client)' : ''}
                      </span>
                    </div>

                    {/* Debit / Credit Totals Breakdown */}
                    <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-100 text-[11px]">
                      <div>
                        <span className="text-slate-400">Total Debit (Dr):</span>{' '}
                        <span className="font-mono font-bold text-emerald-700">
                          {formatCurrency(ledger.totalDebit)}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-400">Total Credit (Cr):</span>{' '}
                        <span className="font-mono font-bold text-rose-700">
                          {formatCurrency(ledger.totalCredit)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Contact / Location Meta */}
                  <div className="space-y-1 text-xs text-slate-600 pt-2 border-t border-slate-100">
                    {company.phone && (
                      <div className="flex items-center gap-1.5">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{company.phone}</span>
                      </div>
                    )}
                    {company.address && (
                      <div className="flex items-start gap-1.5">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0 mt-0.5" />
                        <span className="truncate">{company.address}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="mt-5 pt-3 border-t border-slate-100 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenNewTransaction('GIVE_STOCK', company.id)}
                      className="inline-flex items-center justify-center gap-1 px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold transition-all"
                    >
                      <ArrowUpRight className="w-3.5 h-3.5" />
                      <span>Give Stock</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenNewTransaction('TAKE_STOCK', company.id)}
                      className="inline-flex items-center justify-center gap-1 px-2.5 py-1.5 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 rounded-lg text-xs font-bold transition-all"
                    >
                      <ArrowDownLeft className="w-3.5 h-3.5" />
                      <span>Take Stock</span>
                    </button>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenPaymentModal(company.id)}
                      className="flex-1 inline-flex items-center justify-center gap-1 px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-lg text-xs font-bold transition-all"
                    >
                      <CreditCard className="w-3.5 h-3.5 text-amber-700" />
                      <span>Record Payment</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onOpenLedger(company.id)}
                      className="flex-1 inline-flex items-center justify-center gap-1 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-all"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>View Ledger</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
