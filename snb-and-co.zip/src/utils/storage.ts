import { Company, Transaction, Payment, LedgerEntry, InventoryItem } from '../types';
import { calculateLineItem, calculateAggregatedTotals } from './calculation';

const COMPANIES_KEY = 'snb_companies_v1';
const TRANSACTIONS_KEY = 'snb_transactions_v1';
const PAYMENTS_KEY = 'snb_payments_v1';

// Initial sample seed data for SNB AND CO
function getInitialData() {
  const initialCompanies: Company[] = [
    {
      id: 'comp-1',
      name: 'Apex Traders Pvt Ltd',
      contactPerson: 'Rajesh Sharma',
      phone: '+91 98450 12345',
      email: 'rajesh@apextraders.in',
      address: '124 Commercial Street, APMC Yard, Market Rd',
      gstNumber: '29ABCDE1234F1Z5',
      createdAt: '2026-08-15',
      initialBalance: 0,
    },
    {
      id: 'comp-2',
      name: 'Malabar Spices & Commodities',
      contactPerson: 'K. V. Mathew',
      phone: '+91 94471 88990',
      email: 'malabar.spices@gmail.com',
      address: 'Shop 42, Spice Exchange Market, Cochin',
      gstNumber: '32AABCM5678K1ZR',
      createdAt: '2026-08-20',
      initialBalance: 0,
    },
    {
      id: 'comp-3',
      name: 'Royal Agro Corp',
      contactPerson: 'Anand Patel',
      phone: '+91 98250 44556',
      email: 'contact@royalagro.com',
      address: 'GIDC Industrial Area, Phase 2, Ahmedabad',
      gstNumber: '24AAACR9012D1ZU',
      createdAt: '2026-08-25',
      initialBalance: 0,
    },
    {
      id: 'comp-4',
      name: 'Southern Green Mart',
      contactPerson: 'Senthil Kumar',
      phone: '+91 98401 77665',
      email: 'sgm.chennai@trade.com',
      address: 'Koyambedu Wholesale Market Complex, Chennai',
      gstNumber: '33AABCS4433E1ZQ',
      createdAt: '2026-09-01',
      initialBalance: 0,
    }
  ];

  // Sample transactions with calculation logic:
  // Item 1: Cardamom Premium: 10 boxes * 20 kg = 200 + 5 kg loose = 205 kg total. Less 5% (10.25 kg) = 194.75 kg * 1800 = 350,550
  // Item 2: Black Pepper Bold: 15 boxes * 25 kg = 375 + 2 kg loose = 377 kg total. Less 5% (18.85 kg) = 358.15 kg * 620 = 222,053
  const item1 = calculateLineItem(1, 'Cardamom Special (8mm)', 10, 20, 5, 1800, 5);
  const item2 = calculateLineItem(2, 'Black Pepper Bold (Grade A)', 15, 25, 2, 620, 5);
  const totals1 = calculateAggregatedTotals([item1, item2]);

  const item3 = calculateLineItem(1, 'Nutmeg Kernel A-Grade', 20, 30, 4.5, 540, 5);
  const totals2 = calculateAggregatedTotals([item3]);

  const item4 = calculateLineItem(1, 'Cardamom Special (8mm)', 25, 20, 10, 1750, 5);
  const item5 = calculateLineItem(2, 'Dry Ginger Bleached', 30, 40, 8, 310, 5);
  const totals3 = calculateAggregatedTotals([item4, item5]);

  const initialTransactions: Transaction[] = [
    {
      id: 'tx-1',
      invoiceNumber: 'SNB-INW-0101',
      type: 'TAKE_STOCK', // Purchase inward from Malabar Spices
      companyId: 'comp-2',
      companyName: 'Malabar Spices & Commodities',
      date: '2026-08-28',
      items: [item4, item5],
      totalBoxes: totals3.totalBoxes,
      totalGrossWeight: totals3.totalGrossWeight,
      totalLessWeight: totals3.totalLessWeight,
      totalWeightAfterLess: totals3.totalWeightAfterLess,
      finalInvoiceTotal: totals3.finalInvoiceTotal,
      notes: 'Direct farm inward delivery received at warehouse',
      vehicleNumber: 'KL-07-CD-4545',
      createdAt: '2026-08-28T10:30:00Z',
    },
    {
      id: 'tx-2',
      invoiceNumber: 'SNB-OUT-0201',
      type: 'GIVE_STOCK', // Outward sale to Apex Traders
      companyId: 'comp-1',
      companyName: 'Apex Traders Pvt Ltd',
      date: '2026-09-02',
      items: [item1, item2],
      totalBoxes: totals1.totalBoxes,
      totalGrossWeight: totals1.totalGrossWeight,
      totalLessWeight: totals1.totalLessWeight,
      totalWeightAfterLess: totals1.totalWeightAfterLess,
      finalInvoiceTotal: totals1.finalInvoiceTotal,
      notes: 'Outward stock dispatched via V-Trans lorry',
      vehicleNumber: 'KA-01-EF-8901',
      createdAt: '2026-09-02T14:15:00Z',
    },
    {
      id: 'tx-3',
      invoiceNumber: 'SNB-OUT-0202',
      type: 'GIVE_STOCK', // Outward stock to Royal Agro Corp
      companyId: 'comp-3',
      companyName: 'Royal Agro Corp',
      date: '2026-09-04',
      items: [item3],
      totalBoxes: totals2.totalBoxes,
      totalGrossWeight: totals2.totalGrossWeight,
      totalLessWeight: totals2.totalLessWeight,
      totalWeightAfterLess: totals2.totalWeightAfterLess,
      finalInvoiceTotal: totals2.finalInvoiceTotal,
      notes: 'Export grade consignment dispatched',
      vehicleNumber: 'GJ-03-XY-1234',
      createdAt: '2026-09-04T11:00:00Z',
    }
  ];

  const initialPayments: Payment[] = [
    {
      id: 'pay-1',
      receiptNumber: 'SNB-RCP-001',
      companyId: 'comp-1',
      companyName: 'Apex Traders Pvt Ltd',
      type: 'PAYMENT_RECEIVED',
      amount: 300000,
      paymentMethod: 'BANK_TRANSFER',
      referenceNumber: 'NEFT-HDFC-9912048',
      notes: 'Part payment against Invoice SNB-OUT-0201',
      date: '2026-09-03',
      createdAt: '2026-09-03T16:00:00Z',
    },
    {
      id: 'pay-2',
      receiptNumber: 'SNB-VCH-001',
      companyId: 'comp-2',
      companyName: 'Malabar Spices & Commodities',
      type: 'PAYMENT_PAID',
      amount: 500000,
      paymentMethod: 'BANK_TRANSFER',
      referenceNumber: 'RTGS-SBI-8823101',
      notes: 'Advance settlement against Inward bill SNB-INW-0101',
      date: '2026-08-30',
      createdAt: '2026-08-30T12:00:00Z',
    }
  ];

  return { initialCompanies, initialTransactions, initialPayments };
}

export function getCompanies(): Company[] {
  const data = localStorage.getItem(COMPANIES_KEY);
  if (!data) {
    const { initialCompanies, initialTransactions, initialPayments } = getInitialData();
    localStorage.setItem(COMPANIES_KEY, JSON.stringify(initialCompanies));
    localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(initialTransactions));
    localStorage.setItem(PAYMENTS_KEY, JSON.stringify(initialPayments));
    return initialCompanies;
  }
  try {
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export function saveCompany(company: Company): void {
  const companies = getCompanies();
  const index = companies.findIndex(c => c.id === company.id);
  if (index >= 0) {
    companies[index] = company;
  } else {
    companies.unshift(company);
  }
  localStorage.setItem(COMPANIES_KEY, JSON.stringify(companies));
}

export function deleteCompany(id: string): void {
  const companies = getCompanies().filter(c => c.id !== id);
  localStorage.setItem(COMPANIES_KEY, JSON.stringify(companies));
}

export function getTransactions(): Transaction[] {
  const data = localStorage.getItem(TRANSACTIONS_KEY);
  if (!data) {
    getCompanies(); // triggers init
    return JSON.parse(localStorage.getItem(TRANSACTIONS_KEY) || '[]');
  }
  try {
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export function saveTransaction(tx: Transaction): void {
  const transactions = getTransactions();
  const index = transactions.findIndex(t => t.id === tx.id);
  if (index >= 0) {
    transactions[index] = tx;
  } else {
    transactions.unshift(tx);
  }
  localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(transactions));
}

export function deleteTransaction(id: string): void {
  const transactions = getTransactions().filter(t => t.id !== id);
  localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(transactions));
}

export function getPayments(): Payment[] {
  const data = localStorage.getItem(PAYMENTS_KEY);
  if (!data) {
    getCompanies();
    return JSON.parse(localStorage.getItem(PAYMENTS_KEY) || '[]');
  }
  try {
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export function savePayment(payment: Payment): void {
  const payments = getPayments();
  const index = payments.findIndex(p => p.id === payment.id);
  if (index >= 0) {
    payments[index] = payment;
  } else {
    payments.unshift(payment);
  }
  localStorage.setItem(PAYMENTS_KEY, JSON.stringify(payments));
}

export function deletePayment(id: string): void {
  const payments = getPayments().filter(p => p.id !== id);
  localStorage.setItem(PAYMENTS_KEY, JSON.stringify(payments));
}

/**
 * Calculates auto-balanced Ledger for a specific company
 */
export function getCompanyLedger(companyId: string): {
  entries: LedgerEntry[];
  totalDebit: number;
  totalCredit: number;
  netBalance: number;
  balanceType: 'RECEIVABLE' | 'PAYABLE' | 'SETTLED';
} {
  const transactions = getTransactions().filter(t => t.companyId === companyId);
  const payments = getPayments().filter(p => p.companyId === companyId);
  const company = getCompanies().find(c => c.id === companyId);

  type RawItem = {
    date: string;
    createdAt: string;
    particulars: string;
    type: 'GIVE_STOCK' | 'TAKE_STOCK' | 'PAYMENT_RECEIVED' | 'PAYMENT_PAID';
    refId: string;
    docNo: string;
    debit: number;
    credit: number;
    notes?: string;
  };

  const rawEntries: RawItem[] = [];

  // Opening balance if any
  if (company?.initialBalance && company.initialBalance !== 0) {
    if (company.initialBalance > 0) {
      rawEntries.push({
        date: company.createdAt || '2026-01-01',
        createdAt: '2026-01-01T00:00:00Z',
        particulars: 'Opening Balance (Dr)',
        type: 'GIVE_STOCK',
        refId: 'opening',
        docNo: 'OB-001',
        debit: company.initialBalance,
        credit: 0,
        notes: 'Initial brought forward balance',
      });
    } else {
      rawEntries.push({
        date: company.createdAt || '2026-01-01',
        createdAt: '2026-01-01T00:00:00Z',
        particulars: 'Opening Balance (Cr)',
        type: 'TAKE_STOCK',
        refId: 'opening',
        docNo: 'OB-001',
        debit: 0,
        credit: Math.abs(company.initialBalance),
        notes: 'Initial brought forward balance',
      });
    }
  }

  // Add stock transactions
  transactions.forEach(tx => {
    if (tx.type === 'GIVE_STOCK') {
      // SNB gives stock to client -> Debit client account (they owe us)
      rawEntries.push({
        date: tx.date,
        createdAt: tx.createdAt,
        particulars: `Stock Given (Inv #${tx.invoiceNumber}) - ${tx.items.map(i => i.itemName).join(', ')}`,
        type: 'GIVE_STOCK',
        refId: tx.id,
        docNo: tx.invoiceNumber,
        debit: tx.finalInvoiceTotal,
        credit: 0,
        notes: tx.notes,
      });
    } else {
      // SNB takes stock from client -> Credit client account (we owe them)
      rawEntries.push({
        date: tx.date,
        createdAt: tx.createdAt,
        particulars: `Stock Taken (Inward #${tx.invoiceNumber}) - ${tx.items.map(i => i.itemName).join(', ')}`,
        type: 'TAKE_STOCK',
        refId: tx.id,
        docNo: tx.invoiceNumber,
        debit: 0,
        credit: tx.finalInvoiceTotal,
        notes: tx.notes,
      });
    }
  });

  // Add payments
  payments.forEach(pay => {
    if (pay.type === 'PAYMENT_RECEIVED') {
      // Client paid SNB -> Credit client account (reduces their debit)
      rawEntries.push({
        date: pay.date,
        createdAt: pay.createdAt,
        particulars: `Payment Received (${pay.paymentMethod}${pay.referenceNumber ? ` / ${pay.referenceNumber}` : ''})`,
        type: 'PAYMENT_RECEIVED',
        refId: pay.id,
        docNo: pay.receiptNumber,
        debit: 0,
        credit: pay.amount,
        notes: pay.notes,
      });
    } else {
      // SNB paid client -> Debit client account (reduces their credit)
      rawEntries.push({
        date: pay.date,
        createdAt: pay.createdAt,
        particulars: `Payment Paid (${pay.paymentMethod}${pay.referenceNumber ? ` / ${pay.referenceNumber}` : ''})`,
        type: 'PAYMENT_PAID',
        refId: pay.id,
        docNo: pay.receiptNumber,
        debit: pay.amount,
        credit: 0,
        notes: pay.notes,
      });
    }
  });

  // Sort chronological ascending
  rawEntries.sort((a, b) => {
    const dDiff = new Date(a.date).getTime() - new Date(b.date).getTime();
    if (dDiff !== 0) return dDiff;
    return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
  });

  let running = 0;
  let totalDebit = 0;
  let totalCredit = 0;

  const entries: LedgerEntry[] = rawEntries.map((item, idx) => {
    running += (item.debit - item.credit);
    totalDebit += item.debit;
    totalCredit += item.credit;

    return {
      id: `led-${idx}-${item.refId}`,
      date: item.date,
      particulars: item.particulars,
      type: item.type,
      referenceId: item.refId,
      referenceDocNo: item.docNo,
      debit: item.debit,
      credit: item.credit,
      runningBalance: Number(running.toFixed(2)),
      notes: item.notes,
    };
  });

  const netBalance = Number(running.toFixed(2));
  let balanceType: 'RECEIVABLE' | 'PAYABLE' | 'SETTLED' = 'SETTLED';
  if (netBalance > 0.01) {
    balanceType = 'RECEIVABLE'; // Client owes SNB AND CO
  } else if (netBalance < -0.01) {
    balanceType = 'PAYABLE'; // SNB AND CO owes Client
  }

  return {
    entries,
    totalDebit: Number(totalDebit.toFixed(2)),
    totalCredit: Number(totalCredit.toFixed(2)),
    netBalance,
    balanceType,
  };
}

/**
 * Real-time Inventory Calculation
 * Inward (TAKE STOCK) adds to inventory
 * Outward (GIVE STOCK) deducts from inventory
 */
export function getRealtimeInventory(): InventoryItem[] {
  const transactions = getTransactions();

  // Map item name (normalized) -> inventory data
  const map = new Map<string, {
    displayName: string;
    boxes: number;
    netWeightKg: number;
    rates: number[];
    lastUpdated: string;
    historyCount: number;
  }>();

  // Baseline standard items known to SNB AND CO
  const defaultItems = [
    { name: 'Cardamom Special (8mm)', initBoxes: 50, initWeight: 1000, rate: 1800 },
    { name: 'Black Pepper Bold (Grade A)', initBoxes: 60, initWeight: 1500, rate: 620 },
    { name: 'Nutmeg Kernel A-Grade', initBoxes: 40, initWeight: 1200, rate: 540 },
    { name: 'Dry Ginger Bleached', initBoxes: 50, initWeight: 2000, rate: 310 },
    { name: 'Cloves Premium Madagascar', initBoxes: 30, initWeight: 750, rate: 850 },
  ];

  defaultItems.forEach(d => {
    map.set(d.name.toLowerCase(), {
      displayName: d.name,
      boxes: d.initBoxes,
      netWeightKg: d.initWeight,
      rates: [d.rate],
      lastUpdated: '2026-08-20',
      historyCount: 1,
    });
  });

  // Apply all transactions chronologically
  const sortedTx = [...transactions].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  sortedTx.forEach(tx => {
    tx.items.forEach(item => {
      const key = item.itemName.trim().toLowerCase();
      if (!key) return;

      const current = map.get(key) || {
        displayName: item.itemName.trim(),
        boxes: 0,
        netWeightKg: 0,
        rates: [],
        lastUpdated: tx.date,
        historyCount: 0,
      };

      current.rates.push(item.rate);
      current.historyCount += 1;
      current.lastUpdated = tx.date;

      if (tx.type === 'TAKE_STOCK') {
        // Stock came in
        current.boxes += item.boxes;
        current.netWeightKg += item.weightAfterLess;
      } else {
        // Stock went out
        current.boxes -= item.boxes;
        current.netWeightKg -= item.weightAfterLess;
      }

      map.set(key, current);
    });
  });

  return Array.from(map.values()).map(v => {
    const avgRate = v.rates.length > 0
      ? v.rates.reduce((a, b) => a + b, 0) / v.rates.length
      : 0;

    return {
      itemName: v.displayName,
      totalBoxesInStock: v.boxes,
      totalNetWeightKg: Number(v.netWeightKg.toFixed(3)),
      averageRate: Number(avgRate.toFixed(2)),
      lastUpdated: v.lastUpdated,
      stockHistoryCount: v.historyCount,
    };
  });
}

/**
 * Generate next sequential invoice or voucher number
 */
export function generateNextNumber(prefix: 'OUT' | 'INW' | 'RCP' | 'VCH'): string {
  const currentYear = new Date().getFullYear();
  const randomSuffix = Math.floor(100 + Math.random() * 900);
  return `SNB-${prefix}-${currentYear}-${randomSuffix}`;
}
