import { LineItem } from '../types';

/**
 * Core calculation logic as specified by SNB AND CO:
 * S.NO, ITEM NAME, BOX * WEIGHT OF BOX + LOOSE WEIGHT = TOTAL WEIGHT,
 * THEN LESS 5% = WEIGHT AFTER LESS * RATE = SUB TOTAL.
 * ALL SUB TOTALs should be aggregated to produce a final invoice total for each transaction.
 */
export function calculateLineItem(
  sNo: number,
  itemName: string,
  boxes: number,
  weightPerBox: number,
  looseWeight: number,
  rate: number,
  lessPercentage: number = 5
): LineItem {
  const safeBoxes = Math.max(0, boxes || 0);
  const safeWeightPerBox = Math.max(0, weightPerBox || 0);
  const safeLooseWeight = Math.max(0, looseWeight || 0);
  const safeRate = Math.max(0, rate || 0);
  const safeLessPct = Math.max(0, lessPercentage ?? 5);

  // BOX * WEIGHT OF BOX + LOOSE WEIGHT = TOTAL WEIGHT
  const boxWeightTotal = safeBoxes * safeWeightPerBox;
  const totalWeight = Number((boxWeightTotal + safeLooseWeight).toFixed(3));

  // THEN LESS 5% = WEIGHT AFTER LESS
  const lessWeight = Number(((totalWeight * safeLessPct) / 100).toFixed(3));
  const weightAfterLess = Number((totalWeight - lessWeight).toFixed(3));

  // WEIGHT AFTER LESS * RATE = SUB TOTAL
  const subTotal = Number((weightAfterLess * safeRate).toFixed(2));

  return {
    id: `item-${Date.now()}-${sNo}-${Math.random().toString(36).substring(2, 6)}`,
    sNo,
    itemName: itemName.trim(),
    boxes: safeBoxes,
    weightPerBox: safeWeightPerBox,
    looseWeight: safeLooseWeight,
    totalWeight,
    lessPercentage: safeLessPct,
    lessWeight,
    weightAfterLess,
    rate: safeRate,
    subTotal,
  };
}

export interface AggregatedTotals {
  totalBoxes: number;
  totalGrossWeight: number;
  totalLessWeight: number;
  totalWeightAfterLess: number;
  finalInvoiceTotal: number;
}

export function calculateAggregatedTotals(items: LineItem[]): AggregatedTotals {
  return items.reduce(
    (acc, item) => {
      return {
        totalBoxes: acc.totalBoxes + item.boxes,
        totalGrossWeight: Number((acc.totalGrossWeight + item.totalWeight).toFixed(3)),
        totalLessWeight: Number((acc.totalLessWeight + item.lessWeight).toFixed(3)),
        totalWeightAfterLess: Number((acc.totalWeightAfterLess + item.weightAfterLess).toFixed(3)),
        finalInvoiceTotal: Number((acc.finalInvoiceTotal + item.subTotal).toFixed(2)),
      };
    },
    {
      totalBoxes: 0,
      totalGrossWeight: 0,
      totalLessWeight: 0,
      totalWeightAfterLess: 0,
      finalInvoiceTotal: 0,
    }
  );
}
