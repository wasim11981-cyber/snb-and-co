import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Calculator, 
  Boxes, 
  CreditCard, 
  FileText, 
  PlusCircle, 
  ArrowUpRight, 
  ArrowDownLeft 
} from 'lucide-react';
import { Company, Transaction, Payment, InventoryItem, TransactionType } from './types';
import { 
  getCompanies, 
  saveCompany, 
  getTransactions, 
  saveTransaction, 
  deleteTransaction, 
  getPayments, 
  savePayment, 
  getRealtimeInventory, 
  getCompanyLedger 
} from './utils/storage';
import { Header } from './components/Header';
import { CompaniesLedgerView } from './components/CompaniesLedgerView';
import { TransactionForm } from './components/TransactionForm';
import { InventoryView } from './components/InventoryView';
import { PaymentHistoryView } from './components/PaymentHistoryView';
import { InvoicesListView } from './components/InvoicesListView';
import { InvoiceModal } from './components/InvoiceModal';
import { CompanyLedgerModal } from './components/CompanyLedgerModal';
import { PaymentModal } from './components/PaymentModal';
import { AddCompanyModal } from './components/AddCompanyModal';

export type TabType = 'COMPANIES' | 'NEW_TRANSACTION' | 'INVENTORY' | 'PAYMENTS' | 'INVOICES';

export function App() {
  const [activeTab, setActiveTab] = useState<TabType>('COMPANIES');
  const [companies, setCompanies] = useState<Company[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);

  // Modals state
  const [selectedInvoice, setSelectedInvoice] = useState<Transaction | null>(null);
  const [selectedLedgerCompanyId, setSelectedLedgerCompanyId] = useState<string | null>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);
  const [paymentCompanyId, setPaymentCompanyId] = useState<string | undefined>(undefined);
  const [isAddCompanyOpen, setIsAddCompanyOpen] = useState<boolean>(false);

  // New Transaction Initial States
  const [newTxType, setNewTxType] = useState<TransactionType>('GIVE_STOCK');
  const [newTxCompanyId, setNewTxCompanyId] = useState<string | undefined>(undefined);

  // Load state from local persistence
  const refreshData = () => {
    const comps = getCompanies();
    const txs = getTransactions();
    const pays = getPayments();
    const inv = getRealtimeInventory();

    setCompanies(comps);
    setTransactions(txs);
    setPayments(pays);
    setInventory(inv);
  };

  useEffect(() => {
    refreshData();
  }, []);

  // Compute aggregate company balances
  const totalReceivable = companies.reduce((sum, c) => {
    const l = getCompanyLedger(c.id);
    return l.balanceType === 'RECEIVABLE' ? sum + l.netBalance : sum;
  }, 0);

  const totalPayable = companies.reduce((sum, c) => {
    const l = getCompanyLedger(c.id);
    return l.balanceType === 'PAYABLE' ? sum + Math.abs(l.netBalance) : sum;
  }, 0);

  const totalInventoryWeight = inventory.reduce((sum, i) => sum + i.totalNetWeightKg, 0);
  const totalInventoryBoxes = inventory.reduce((sum, i) => sum + i.totalBoxesInStock, 0);

  // Handle New Transaction Open
  const handleOpenNewTransaction = (type: TransactionType, companyId?: string) => {
    setNewTxType(type);
    setNewTxCompanyId(companyId);
    setActiveTab('NEW_TRANSACTION');
  };

  // Handle Transaction Saved
  const handleSaveTransaction = (tx: Transaction) => {
    saveTransaction(tx);
    refreshData();
    setSelectedInvoice(tx); // immediately show generated invoice
    setActiveTab('INVOICES');
  };

  // Handle Transaction Deleted
  const handleDeleteTransaction = (id: string) => {
    deleteTransaction(id);
    refreshData();
  };

  // Handle Payment Saved
  const handleSavePayment = (payment: Payment) => {
    savePayment(payment);
    refreshData();
    setIsPaymentModalOpen(false);
  };

  // Handle Add Company Saved
  const handleSaveCompany = (company: Company) => {
    saveCompany(company);
    refreshData();
    setIsAddCompanyOpen(false);
  };

  const selectedLedgerCompany = companies.find(c => c.id === selectedLedgerCompanyId);

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-900">
      {/* Top Header with Brand & Metrics */}
      <Header
        totalReceivable={totalReceivable}
        totalPayable={totalPayable}
        totalInventoryWeight={totalInventoryWeight}
        totalInventoryBoxes={totalInventoryBoxes}
        onOpenNewTransaction={handleOpenNewTransaction}
        onOpenPaymentModal={() => {
          setPaymentCompanyId(undefined);
          setIsPaymentModalOpen(true);
        }}
      />

      {/* Main Tab Navigation Bar */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-1 sm:space-x-4 overflow-x-auto py-2.5">
            <button
              onClick={() => setActiveTab('COMPANIES')}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'COMPANIES'
                  ? 'bg-sky-50 text-sky-700 shadow-xs border border-sky-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>Ledger & Companies</span>
            </button>

            <button
              onClick={() => setActiveTab('NEW_TRANSACTION')}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'NEW_TRANSACTION'
                  ? 'bg-amber-50 text-amber-800 shadow-xs border border-amber-300'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Calculator className="w-4 h-4 text-amber-600" />
              <span>New Stock Calculation & Invoice</span>
            </button>

            <button
              onClick={() => setActiveTab('INVENTORY')}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'INVENTORY'
                  ? 'bg-sky-50 text-sky-700 shadow-xs border border-sky-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Boxes className="w-4 h-4" />
              <span>Real-Time Inventory</span>
            </button>

            <button
              onClick={() => setActiveTab('PAYMENTS')}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'PAYMENTS'
                  ? 'bg-sky-50 text-sky-700 shadow-xs border border-sky-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>Payment History</span>
            </button>

            <button
              onClick={() => setActiveTab('INVOICES')}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'INVOICES'
                  ? 'bg-sky-50 text-sky-700 shadow-xs border border-sky-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Invoices & Bills ({transactions.length})</span>
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content View */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'COMPANIES' && (
          <CompaniesLedgerView
            companies={companies}
            transactions={transactions}
            payments={payments}
            onOpenLedger={(compId) => setSelectedLedgerCompanyId(compId)}
            onOpenNewTransaction={(type, compId) => handleOpenNewTransaction(type, compId)}
            onOpenPaymentModal={(compId) => {
              setPaymentCompanyId(compId);
              setIsPaymentModalOpen(true);
            }}
            onAddNewCompany={() => setIsAddCompanyOpen(true)}
          />
        )}

        {activeTab === 'NEW_TRANSACTION' && (
          <TransactionForm
            companies={companies}
            initialType={newTxType}
            selectedCompanyId={newTxCompanyId}
            onSave={handleSaveTransaction}
            onCancel={() => setActiveTab('COMPANIES')}
            onAddNewCompany={() => setIsAddCompanyOpen(true)}
          />
        )}

        {activeTab === 'INVENTORY' && (
          <InventoryView
            inventory={inventory}
            transactions={transactions}
            onOpenNewTransaction={handleOpenNewTransaction}
          />
        )}

        {activeTab === 'PAYMENTS' && (
          <PaymentHistoryView
            payments={payments}
            companies={companies}
            onOpenPaymentModal={(compId) => {
              setPaymentCompanyId(compId);
              setIsPaymentModalOpen(true);
            }}
            onOpenLedger={(compId) => setSelectedLedgerCompanyId(compId)}
          />
        )}

        {activeTab === 'INVOICES' && (
          <InvoicesListView
            transactions={transactions}
            onViewInvoice={(tx) => setSelectedInvoice(tx)}
            onOpenLedger={(compId) => setSelectedLedgerCompanyId(compId)}
            onDeleteTransaction={handleDeleteTransaction}
            onOpenNewTransaction={handleOpenNewTransaction}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <span className="font-bold text-slate-800">SNB AND CO</span> &bull; Wholesale Stock Trading & Commission System
          </div>
          <div>
            Calculation Logic: <span className="font-mono font-medium">(Box × Wt + Loose) Less 5% × Rate = Sub Total</span>
          </div>
        </div>
      </footer>

      {/* Invoice Modal */}
      {selectedInvoice && (
        <InvoiceModal
          transaction={selectedInvoice}
          onClose={() => setSelectedInvoice(null)}
          onOpenLedger={(compId) => {
            setSelectedInvoice(null);
            setSelectedLedgerCompanyId(compId);
          }}
        />
      )}

      {/* Company Ledger Statement Modal */}
      {selectedLedgerCompany && (
        <CompanyLedgerModal
          company={selectedLedgerCompany}
          transactions={transactions}
          onClose={() => setSelectedLedgerCompanyId(null)}
          onOpenNewTransaction={(type, compId) => {
            setSelectedLedgerCompanyId(null);
            handleOpenNewTransaction(type, compId);
          }}
          onOpenPaymentModal={(compId) => {
            setPaymentCompanyId(compId);
            setIsPaymentModalOpen(true);
          }}
          onViewInvoice={(tx) => setSelectedInvoice(tx)}
        />
      )}

      {/* Record Payment Modal */}
      {isPaymentModalOpen && (
        <PaymentModal
          companies={companies}
          initialCompanyId={paymentCompanyId}
          onSave={handleSavePayment}
          onClose={() => setIsPaymentModalOpen(false)}
        />
      )}

      {/* Add Company Modal */}
      {isAddCompanyOpen && (
        <AddCompanyModal
          onSave={handleSaveCompany}
          onClose={() => setIsAddCompanyOpen(false)}
        />
      )}
    </div>
  );
}
export default App;
